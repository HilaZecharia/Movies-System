/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "DecoratorSort.h"
#include "SortByID.h"
#include "SortByAge.h"
#include "SortByNumOfMovies.h"
#include "Professional.h"


/**************************************************************
* the function setSort(int sortType) receive the type of sort
* and set it into the sort object
*************************************************************/
void DecoratorSort::setSort(int sortType){

	switch(sortType){
	case 1:
		sortPro=new SortByID();
		break;
	case 2:
		sortPro=new SortByAge();
		break;
	case 3:
		sortPro=new SortByNumOfMovies();
		break;
	}
}

/*************************************************************
* the function operator()(Professional *pro1,Professional *pro2)
* is overloading the () operator for the sort function
**************************************************************/
bool DecoratorSort::operator()(Professional *pro1,Professional *pro2){
    bool bolian;
    bolian=sortPro->operator()(pro1,pro2);
	return bolian;
}

/*************************************************************
* distructor of the DecoratorSort  class
************************************************************/
DecoratorSort::~DecoratorSort() { }

