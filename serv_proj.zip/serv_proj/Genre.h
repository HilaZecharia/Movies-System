/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef GENRE_H_
#define GENRE_H_

#include <string>
#include <iostream>
#include <vector>
#include "Output.h"
#include "Movie.h"


using namespace std;

/*Forward declaration */
class Output;
class Movie;
/**************************************************************
* The class Genre represents the genre structure of each movie.
**************************************************************/
class Genre{

	public:
	/************************************************************************
	* The constructor  Genre(String s ) gets string and initialize the member
	* genreString by it.
	************************************************************************/
	Genre(string s);
	/************************************************************************
	* The constructor Genre () is a default constructor.
	************************************************************************/
	Genre();
	/***********************************************************************
	* The function setString(String s) set the genreString member by s.
	***********************************************************************/
	void setString(string s);
	/***********************************************************************
	* The function getGenreString() return the string of genreString member
	***********************************************************************/
	string getGenreString();
	/***********************************************************************
	 * the function getValueToSearchBy() use to get
	 * the genre string in the generic search function.
	 * the function return the genre string .
	 **********************************************************************/
	 string getValueToSearchBy();
	 /**********************************************************************
	  * the function addMovieToVector(Movie *movie)  receive a pointer to
	  * movie and add it to the movie vector.
	  *********************************************************************/
	  void addMovieToVector(Movie *movie);
	  /*********************************************************************
	   * the function deleteMovie(string code) receive code of the movie which
	   * want to delete and delete it from the vector .
	   *********************************************************************/
	  void deleteMovie(string code);
	  /********************************************************************
	   * the function printMymovies() print all the movie that belongs to
	   * this genre .
	   *******************************************************************/
	  string printMymovies();
	  /***********************************************************************
	  * Distructor of Genre class
	  **********************************************************************/
	  ~Genre();

	private:

	 	  string genreString;
	 	  vector<Movie*> GenreMoviesList;
};

#endif
