/*
 * SearchInVector.h
 *
 *  Created on: Nov 29, 2015
 *      Author: hila
 */

#ifndef SEARCHINVECTOR_H_
#define SEARCHINVECTOR_H_
#include <vector>
#include <iostream>
#include "Genre.h"
#include "Professional.h"
#include "Movie.h"


using namespace std;
class Genre;
class SearchInVector{
	public :

	    template <class T>

T* search(vector<T*> vector,string searchBy){
		typename std::vector<T*>::iterator it;

		string value;
		int result;
		for(it=(vector).begin();it!=(vector).end();++it)
		{
			value=(string)(*it)->getValueToSearchBy();
			result=value.compare(searchBy);
			if(!result)
				return *it; //if the element found in the vector return it
		}
		return NULL; // if the element didn't found in the vector

}

template <class T>
void unionVectors(vector<T*> vectorOther,vector<T*> &vector){
	typename std::vector<T*>::iterator it;
	it=(vectorOther).begin();
	while ( it != (vectorOther).end()){

	/*if the professional doesn't exist in the vector Movie _A*/
		if((findInVector(vector,*it))==false )
			/*add the professional to the united movie*/
			(vector).push_back(*it);

		it++;

	}
}

template <class T>
bool findInVector(vector<T*> vector,T* element){
	string value;
	string searchBy=(string)(element)->getValueToSearchBy();
	int result;
	typename std::vector<T*>::iterator it;
	for(it=(vector).begin();it!=(vector).end();++it){
		value=(string)(*it)->getValueToSearchBy();
		result=value.compare(searchBy);
		if(!result)
			return true; //if the element found in the vector return true
	}
	return false;
}




		 ~SearchInVector(){

		 }

};



#endif /* SEARCHINVECTOR_H_ */
