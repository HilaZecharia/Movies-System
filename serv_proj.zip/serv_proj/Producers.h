/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef PRODUCERS_H_
#define PRODUCERS_H_

#include <string>
#include <iostream>
#include <vector>
#include "Movie.h"
#include "Output.h"
using namespace std;
/*************************************************************
* The class Producers is derived class of class Professional
* Class Directors represent the producers of the movies.
*************************************************************/
class Producers:public Professional{
	public:
	/*****************************************************************
	* constructor of Producers class,inherited from Professional's
	* constructor.
	****************************************************************/
	Producers(string ID,string name,string specificDes,int age,string gender);
	/********************************************************
	* The function printProfessional() implements the virtual
	* printProfessional() function in the base class .
	* the function print the professional details
	* according its type.
	*********************************************************/
	string printProfessional();
	/**********************************************************
	* The function printMyMovies() implements the virtual
	* printMyMovies() function in the base class .
	* the function print the movie  details of each professional
	* according its type.
	***********************************************************/
	string printMyMovies();
	/*******************************************************************
	* the function getNumOfMovies() return the number of movies
	* the producer participate at.
	*******************************************************************/
	int  getNumOfMovies();
	/*******************************************************************
	* the function addMovieToVector(Movie *movie) get a pointer to movie
	* and add it to the private producer movie vector
	*******************************************************************/
	void addMovieToVector(Movie *movie);
	/********************************************************************
	* the function DeleteMovieFromVector(string code) receive the code
	* of the movie which want to delete,and delete it from the
	* private producer movie vector.
	*******************************************************************/
	void DeleteMovieFromVector(string code);
	/*******************************************************************
	* distructor of Producers class
	*******************************************************************/
	~Producers();
	private:
	    /*******************************************************************
		* vector of all the movies which the producer participate at
		*******************************************************************/
		vector<Movie*> personalMovieList;
};
#endif
