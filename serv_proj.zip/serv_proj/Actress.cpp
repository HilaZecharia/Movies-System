/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "Actress.h"

 /*****************************************************************
 * constructor of Actress class,inherited from Professional's
 * constructor.
 ****************************************************************/
 Actress::Actress(string ID,string name,string specificDes,int age,string gender):
                  Professional(ID,name,specificDes,age,gender){ }

 /****************************************************************************
* The function printProfessional() implements the virtual printProfessional()
* function in the base class . the function print the professional details
* according its type.
****************************************************************************/
string Actress::printProfessional(){
	string str;
	char arr[5];
	sprintf(arr,"%d",age) ;//convert the age to string
	string strAge(arr);
	str=name+" "+strAge;
	return str;
}

/**********************************************************************
* The function printMyMovies() implements the virtual printMyMovies()
* function in the base class . the function print the movie  details of
* function  each function professional according its type.
***********************************************************************/
string Actress::printMyMovies(){
	Output output;
	string str;
	string retStr;
	vector<Movie*>::iterator it;
	for(it=(personalMovieList).begin();it!=(personalMovieList).end();++it){
		str=output.printMovie(*it);
		retStr=retStr+str;
	}
	return retStr;
}

/*******************************************************************
* the function addMovieToVector(Movie *movie) get a pointer to movie
* and add it to the private actress movie vector
*******************************************************************/
void Actress::addMovieToVector(Movie *movie){
	personalMovieList.push_back(movie);
}
/*******************************************************************
* the function getNumOfMovies() return the number of movies
* the actress participate at.
*******************************************************************/
int Actress::getNumOfMovies(){
	return personalMovieList.size();
}
/********************************************************************
* the function DeleteMovieFromVector(string code) receive the code
* of the movie which want to delete,and delete it from the
* private actress movie vector.
*******************************************************************/
 void Actress::DeleteMovieFromVector(string code){
	 vector<Movie*>::iterator it;
	 int result;
	 for(it=(personalMovieList).begin();it !=(personalMovieList).end();++it){
		 result=code.compare((*it)->getCode());
		 if(result==0){
			 personalMovieList.erase(it);
			 break;
		 }
	 }
 }
/**********************************************************************
 * distructor of the Actress class
 *********************************************************************/
Actress::~Actress(){ }
