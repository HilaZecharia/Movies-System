/* Hila Zecharia 204008007 8921004*/

/************************************************************************
* The main receive argument and create the specific kind of server
* acorrding it arguments.
************************************************************************/

#include "SystemAdministrator.h"
#include "Server.h"
#include "ServerUDP.h"
#include "ServerTCP.h"
#include <stdio.h>

int main(int argc,char *argv[]){
	//cout<<argv[0]<<endl;
	//cout<<argv[1]<<endl;
	//cout<<argv[2]<<endl;
	int type;
	Server *serv;

	int port;
	/*if we don't recieve 3 parameters -> error */
	if(argc!=3)
		cout<<"Error"<<endl;

	else{


			sscanf ((argv[1]), "%d",&type);//convert char* to int

			sscanf ((argv[2]), "%d",&port);//convert char* to int

			const int serverPort=port;//get the server port
			if(type==0){
				serv=new ServerUDP(serverPort);	//server UDP
			}
			else{
				serv=new ServerTCP(serverPort); //server tcp
			}

			if(serv->connectTheServer()){ //if the connection succeed
				/*the server start to execute the client command*/
				serv->StartServer(serv);
			}

	}

	return 0;
}

