/*
 * Server.cpp
 *
 *  Created on: Dec 16, 2015
 *      Author: hila
 */

#include "Server.h"
#define STOP_RUNING -1

/************************************************************
 * constructor of the server class
 * *********************************************************/
Server::Server(const int& server_port) {
	/*initialize the struct sin */
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = htons(server_port);

	sock=0;
}
/************************************************************
 * the function creatSocket() create the socked descriptor
 * if the socket create successfully return true, else
 * return false.
 * *********************************************************/
 bool Server::creatSocket(){

	return true;
}
 /***********************************************************
  * the function readTheClientMassage() read the client
  * massage from the socket ,if the reading success return
  * true ,else return false.
  **********************************************************/
bool Server::readTheClientMassage(){
	return true;

}
/************************************************************
 * the function sendToClient(string str) send the output
 * to the client by the socket.
 ***********************************************************/
void Server::sendToClient(string str){

}
/***********************************************************
 * the fucntion connectTheServer() calls the connection
 * server to socket function accorting the server type.
 **********************************************************/
bool Server::connectTheServer(){
	return false;
}
/***********************************************************
 * the fucnction doBind() binding the socked to the server
 * port.if the binding succses return true,else return false.
 * ********************************************************/
bool Server::doBind(){

	if (bind(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
	        perror("error binding to socket");
	        return false;
	}
	return true;
}
/***********************************************************
* The StartServer(Server *server) function is responsible on
* keeping the server running all the time in order to get
* client's commands and perform them .
************************************************************/
void Server:: StartServer(Server *server){
	SystemAdministrator admin;
	Menu menu;
	string copybuf;
	string str;
	int option;

	if(readTheClientMassage()){
		 copybuf=buffer;//convert the socket buffer to string

		option=menu.selectOption(copybuf);

		while(option!=STOP_RUNING )
		{
			 /*check if the selected option is valid*/
			if(menu.isOptionValid(option)==false){

				sendToClient("Failure\n");
			}
			/*if the selected option s valid */
			else{
				str=admin.runOption(option,copybuf);
				sendToClient(str);
			}
			/*waiting for another command from client*/
			if(readTheClientMassage()){
				copybuf=buffer;//convert the socket buffer to string
				option=menu.selectOption(copybuf);
			}

			else {// the read fail
				cout<<"read fail"<<endl;
				break;
			}

		}
	}

	else {//the read fail
		cout<<"read fail"<<endl;
	}

	close(sock);
	return;

}
/*distructor */
Server::~Server() {

}

