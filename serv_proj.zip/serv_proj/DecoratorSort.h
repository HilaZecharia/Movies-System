/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#ifndef DECORATORSORT_H_
#define DECORATORSORT_H_
/********************************************************************
 * the class DecoratorSort perform the decorator pattern
 * in OOP to be able use the sort function in c++
 *******************************************************************/
#include "Sort.h"
#include "Professional.h"
class DecoratorSort {
	public:
		  /**************************************************************
		   * the function setSort(int sortType) receive the type of sort
		   * and set it into the sort object
		   *************************************************************/
		  void setSort(int sortType);
		  /*************************************************************
		   * the function operator()(Professional *pro1,Professional *pro2)
		   * is overloading the () operator for the sort function
		   **************************************************************/
		  bool operator()(Professional *pro1,Professional *pro2);
		  /*************************************************************
		   * distructor of the DecoratorSort  class
		   ************************************************************/
		 ~DecoratorSort();

	private:
		 Sort *sortPro;
};

#endif /* DECORATORSORT_H_ */
