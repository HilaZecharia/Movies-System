/*
 * ServerTCP.cpp
 *
 *  Created on: Dec 17, 2015
 *      Author: hila
 */

#include "ServerTCP.h"

/************************************************************
* constructor of the ServerTCP class,inherited from Server
* class constructor.
* **********************************************************/
ServerTCP::ServerTCP(const int server_port):Server(server_port){
	client_sock=0;
}
/***********************************************************
* the fucntion connectTheServer() calls the connection
* server to socket function accorting the TCP protocol.
**********************************************************/
bool ServerTCP::connectTheServer(){

	if(creatSocket()==false)
		return false;// if the secket not created succesfuly
	if(doBind()==false)
		return false;
	/*initialize the server to connected only one client */
	if (listen(sock, 1) < 0) {
		perror("error listening to a socket");
		return false;
	}
	if(acceptTheConnection()==false)
		return false;

	return true;//the server connected the socket succesfuly

}

/************************************************************
* the function creatSocket() create the socked descriptor for
* the TCP server .if the socket create successfully return
* true, else return false.
* *********************************************************/
 bool ServerTCP::creatSocket(){
	//the tcp server create the socket
	 sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		perror("server: error creating udp socket");
		return false;
	}
	return true;
}

/***********************************************************
* the function acceptTheConnection() accepting the client's
* connection.if the acception sucsseed return true, else
* return false.
************************************************************/
bool ServerTCP::acceptTheConnection(){

   unsigned int addr_len = sizeof(client_sin);
   client_sock = accept(sock,  (struct sockaddr *) &client_sin,  &addr_len);
   if (client_sock < 0) {
       perror("error accepting client");
       return false;
   }
   return true;
}
/***********************************************************
* the function readTheClientMassage() read the client
* massage from the socket ,if the reading success return
* true ,else return false.
**********************************************************/
bool ServerTCP::readTheClientMassage(){
	memset(&buffer, 0, sizeof(buffer));
	 int read_bytes = recv(client_sock, buffer, sizeof(buffer), 0);

	  if (read_bytes <= 0) {
		 perror("reading the client massage fail");
		 return false;
	 }

	 return true;
 }
/************************************************************
* the function sendToClient(string str) send the output
* to the client by the socket.
***********************************************************/
 void ServerTCP::sendToClient(string str){

	 	memset(&buffer, 0, sizeof(buffer));
     /*convert the string to array*/
	 strcpy(buffer, str.c_str());


    int sent_bytes = send(client_sock, buffer, sizeof(buffer), 0);

    if (sent_bytes < 0) {
        perror("error sending to client");
    }
 }

/*distructor */
ServerTCP::~ServerTCP() {

}

