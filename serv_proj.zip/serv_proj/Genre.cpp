/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#define INITIALIZE_STRING ""
#include "Genre.h"
/************************************************************************
* The constructor  Genre(String s ) gets string and initialize the member
* genreString by it.
************************************************************************/
Genre::Genre(string s){
	this->genreString=s;
}
/**********************************************************************
* the function addMovieToVector(Movie *movie)  receive a pointer to
* movie and add it to the movie vector.
*********************************************************************/
void Genre::addMovieToVector(Movie *movie){
	GenreMoviesList.push_back(movie);
}
string Genre::printMymovies(){
	string movieStr;
	string retStr;
	vector<Movie*>::iterator it;
	Output output;
	for(it=(GenreMoviesList).begin(); it !=(GenreMoviesList).end(); ++it){
		movieStr=output.printMovie(*it);
		retStr=retStr+movieStr;
	}
	return retStr;
}
/*********************************************************************
* the function deleteMovie(string code) receive code of the movie which
* want to delete and delete it from the vector .
*********************************************************************/
void Genre::deleteMovie(string code){
	vector<Movie*>::iterator it;
	int result;
	string currentCode;
	for(it=(GenreMoviesList).begin(); it !=(GenreMoviesList).end(); ++it){
		currentCode=(*it)->getCode();
		result=code.compare(currentCode);
		/*delete the movie*/
		if(!result){
			 GenreMoviesList.erase(it);
			 break;
		}
	}
}

/***********************************************************************
* The function setString(String s) set the genreString member by s.
***********************************************************************/
void Genre::setString(string s){  }
/***********************************************************************
* The function getGenreString() return the string of genreString member
***********************************************************************/
string Genre::getGenreString(){
	return genreString;
}
/***********************************************************************
* the function getValueToSearchBy() use to get
* the genre string in the generic search function.
* the function return the genre string .
**********************************************************************/
string Genre::getValueToSearchBy(){
	return  getGenreString();
}
/***********************************************************************
* Distructor of Genre class
***********************************************************************/
Genre::~Genre(){ }
