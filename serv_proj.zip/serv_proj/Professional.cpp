/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include <string>
#include <iostream>
#include <vector>

#include "Professional.h"


/********************************************************************
* constructor That initialize the professional object
* by the user input
********************************************************************/
Professional::Professional(string ID,string name,string specificDes,
		                   int age,string gender){
    this->ID=ID;
    this->age=age;
    this->gender=gender;
    this->name=name;
    this->specificDes=specificDes;
}

/******************************************************************
* the function getSpecificDes() return the spcific description of the
* professional according its type
******************************************************************/
string Professional::getSpecificDes(){
	return specificDes;
}

/********************************************************************
* The function getID() return the professional ID
********************************************************************/
string Professional::getID(){
	return ID;
}
/********************************************************************
* The function printProfessional() is a virtual function that the
* derived class implements. The purpose of this function in to print
* the professional according it type.
*********************************************************************/
string  Professional::printProfessional(){return ""; }
/*********************************************************************
* the function addMovieToVector(Movie* movie)  is a
* virtual function which receive a pointer
* to movie and add it to the private professional movies vector
*********************************************************************/
void Professional::addMovieToVector(Movie* movie){}
/********************************************************************
* the function getNumOfMovies() is a virtual function which
* return the number of movie that each professional participate at
********************************************************************/
 int  Professional::getNumOfMovies(){
	 return 0;
 }

/********************************************************************
* the function getAge() return the professional's age
*******************************************************************/
int Professional::getAge(){
	return age;
}
/*********************************************************************
* The function printMyMovies()is a virtual function that the derived
* class implements. The purpose of this function in to print the movies
* of each professional according his type.
**********************************************************************/
string  Professional::printMyMovies(){return ""; }
/********************************************************************
* The function getValueToSearchBy() use to get the professional
* ID in the generic search function. the function return the
* ID string of the current professional.
********************************************************************/
string Professional::getValueToSearchBy(){
	return getID();
}
/*******************************************************************
* the function getName() return the name of the professional
******************************************************************/
string Professional::getName(){
	return name;
}
/********************************************************************
* the function DeleteMovieFromVector(string code) is a virtual
* function which receive the code of movie we want to delete
* and delete it from the private movies vector in the derived classes
*********************************************************************/
 void Professional::DeleteMovieFromVector(string code){ }

 /********************************************************************
* the function deletePro(Professional *pro) receive a pointer to
* the professional which we wand to delete and delete it from the memory
**********************************************************************/
 void Professional::deletePro(Professional *pro){
	 delete pro;
 }

/*********************************************************************
* Distructor of the Professional class
********************************************************************/
Professional::~Professional(){ }






