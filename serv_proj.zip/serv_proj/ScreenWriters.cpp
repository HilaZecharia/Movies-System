/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "ScreenWriters.h"

/*****************************************************************
* constructor of  ScreenWriters class,inherited from Professional's
* constructor.
****************************************************************/
ScreenWriters::ScreenWriters(string ID,string name,string specificDes,int age,
		                     string gender):Professional(ID,name,specificDes,
		                     age,gender){ }
/************************************************************
* The function printProfessional() implements the virtual
* printProfessional() function in the base class .
* the function print the professional details
* according its type.
*************************************************************/
string ScreenWriters::printProfessional(){
	string str;
	str=name+" "+specificDes;
	return str;
}
/*******************************************************************
* the function getNumOfMovies() return the number of movies
* the ScreenWriters participate at.
*******************************************************************/
int  ScreenWriters::getNumOfMovies(){
	return personalMovieList.size();
}
/************************************************************
* The function printMyMovies() implements the virtual
* printMyMovies() function in the base class .
* the function print the movie  details of each professional
* according its type.
*************************************************************/
string ScreenWriters::printMyMovies(){
	Output output;
	string str;
	string retStr;
	vector<Movie*>::iterator it;
	for(it=(personalMovieList).begin(); it !=(personalMovieList).end(); ++it) {
		str=output.printMovie(*it);
		retStr=retStr+str;
	}
	return retStr;
}
/*******************************************************************
* the function addMovieToVector(Movie *movie) get a pointer to movie
* and add it to the private ScreenWriters movie vector
*******************************************************************/
void ScreenWriters::addMovieToVector(Movie *movie){
	personalMovieList.push_back(movie);
}
/********************************************************************
* the function DeleteMovieFromVector(string code) receive the code
* of the movie which want to delete,and delete it from the
* private ScreenWriters movie vector.
*******************************************************************/
void ScreenWriters::DeleteMovieFromVector(string code){
	 vector<Movie*>::iterator it;
	 int result;
	 for(it=(personalMovieList).begin(); it !=(personalMovieList).end(); ++it){
		 result=code.compare((*it)->getCode());
		 /* if the movie we search for found */
		 if(!result){
			 /*delete the movie*/
			 personalMovieList.erase(it);
			 break;
		 }
	 }
}
/************************************************************
* Distructor of the ScreenWriters class
************************************************************/
ScreenWriters::~ScreenWriters(){}
