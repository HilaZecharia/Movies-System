/*
 * ServerUDP.h
 *
 *  Created on: Dec 16, 2015
 *      Author: hila
 */

#ifndef SERVERUDP_H_
#define SERVERUDP_H_
#include "Server.h"


#include <string>
#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
using namespace std;

/**************************************************
 * the class ServerUDP inherite from Server class
 * and  perform the UDP server function
 **************************************************/
class ServerUDP:public Server {
public:
	/************************************************************
	* constructor of the ServerUDP class,inherited from Server
	* class constructor.
	* **********************************************************/
	ServerUDP(const int server_port);
	/***********************************************************
	* the fucntion connectTheServer() calls the connection
	* server to socket function accorting the UDP protocol.
	**********************************************************/
	bool connectTheServer();
	/************************************************************
	* the function creatSocket() create the socked descriptor for
	* the UDP server .if the socket create successfully return
	* true, else return false.
	* *********************************************************/
	bool creatSocket();
	/***********************************************************
	* the function readTheClientMassage() read the client
	* massage from the socket ,if the reading success return
	* true ,else return false.
	**********************************************************/
	bool readTheClientMassage();
	/************************************************************
	* the function sendToClient(string str) send the output
	* to the client by the socket.
	***********************************************************/
	void sendToClient(string str);
	/*distructor */
	 ~ServerUDP();
private:
	struct sockaddr_in sin;
	struct sockaddr_in from;
};

#endif /* SERVERUDP_H_ */
