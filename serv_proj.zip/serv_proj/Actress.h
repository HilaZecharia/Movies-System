/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef ACTRESS_H_
#define ACTRESS_H_
/****************************************************************************
* The class Actress is derived class of class Professional .
* Class Directors represent the actress of the movies.
*****************************************************************************/
#include <string>
#include <iostream>
#include <vector>
#include "Movie.h"
#include "Professional.h"
#include "Output.h"
#include <stdio.h>

using namespace std;

class Actress:public Professional{
	public:
	    /*****************************************************************
	     * constructor of Actress class,inherited from Professional's
	     * constructor.
	     ****************************************************************/
		Actress(string ID,string name,string specificDes,int age,string gender);
		/******************************************************************
		* The function printProfessional() implements the virtual
		* printProfessional() function in the base class .
		* the function print the professional details according its type.
		******************************************************************/
		string printProfessional();
		/******************************************************************
		* The function printMyMovies() implements the virtual
		* printMyMovies() function in the base class .
		* the function print the movie  details of
		* function  each function professional according its type.
		*******************************************************************/
		string printMyMovies();
		/*******************************************************************
		 * the function getNumOfMovies() return the number of movies
		 * the actress participate at.
		 *******************************************************************/
		int getNumOfMovies();
		/*******************************************************************
		 * the function addMovieToVector(Movie *movie) get a pointer to movie
		 * and add it to the private actress movie vector
		 *******************************************************************/
		void addMovieToVector(Movie *movie);
		/********************************************************************
		 * the function DeleteMovieFromVector(string code) receive the code
		 * of the movie which want to delete,and delete it from the
		 * private actress movie vector.
		 *******************************************************************/
		void DeleteMovieFromVector(string code);
		/*******************************************************************
		 * distructor of the Actress class
		 *******************************************************************/
		~Actress();
	private:
		/*******************************************************************
		 * vector of all the movies which the actress participate at
		 *******************************************************************/
		 vector<Movie*> personalMovieList;
};
#endif
