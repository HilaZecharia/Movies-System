#ifndef Output_H_
#define Output_H_

#include "Movie.h"
#include "Professional.h"
#include <iostream>
#include <string>
#include <sstream>


using namespace std;

class Movie;
/*************************************************************
 * the class Output responsible to display the program output
 * in the  stdout
 ************************************************************/
class Output{

	public :
		/********************************************************
		* the function printSuccess() print "success" to stdout
		*******************************************************/
		string printSuccess();
		/********************************************************
		* the function  printFailure() print "failure" to stdout
		*******************************************************/
		string printFailure();
		/*******************************************************
		 * the function printMovie(Movie *movie) receive  a
		 * pointer to specific movie and print it details
		 ******************************************************/
		 string printMovie(Movie *movie);
		 string printPro(Professional *pro);
		 string printMoviePro(Movie *movie);
};



#endif
