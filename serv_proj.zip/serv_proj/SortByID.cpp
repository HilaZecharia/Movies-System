/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "SortByID.h"

/****************************************************************
* the function operator()(Professional *pro1,Professional *pro2)
* receive two pointers to professionals and compare between them
* by ID, the function return true if pro1 ID is smaller the pro2
* ID,and false otherwise .
*****************************************************************/
bool SortByID::operator()(Professional *pro1,Professional *pro2) {
	int cmpResult;
	string ID1,ID2;
	ID1=pro1->getID();
	ID2=pro2->getID();
	cmpResult=ID1.compare(ID2);
	/*if the  prefix of the pro 1 ID in bigger in Lexicographicaly way */
	if(cmpResult>0)
		return false;
	/*if the prefix of the pro 2 ID in bigger in Lexicographicaly way */
	else
		return true;
}
/*******************************************************************
* virtual distructor of the SortByID class
******************************************************************/
SortByID::~SortByID() { }

