/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "Producers.h"

/*****************************************************************
* constructor of Producers class,inherited from Professional's
* constructor.
****************************************************************/
Producers::Producers(string ID,string name,string specificDes,int age,
		             string gender):Professional(ID,name,specificDes,
		             age,gender){ }
/********************************************************
* The function printProfessional() implements the virtual
* printProfessional() function in the base class .
* the function print the professional details
* according its type.
*********************************************************/
string Producers::printProfessional(){
	return name;
}
/*******************************************************************
* the function getNumOfMovies() return the number of movies
* the producer participate at.
*******************************************************************/
int  Producers::getNumOfMovies(){
	return personalMovieList.size();
}
/********************************************************************
* the function DeleteMovieFromVector(string code) receive the code
* of the movie which want to delete,and delete it from the
* private producer movie vector.
*******************************************************************/
void Producers::DeleteMovieFromVector(string code){
	 vector<Movie*>::iterator it;
	 int result;
	 for(it=(personalMovieList).begin(); it!=(personalMovieList).end();++it){
		 result=code.compare((*it)->getCode());
		 if(!result){
			 /*delete the movie*/
			 personalMovieList.erase(it);
			 break;
		 }
	 }
}
/**********************************************************
* The function printMyMovies() implements the virtual
* printMyMovies() function in the base class .
* the function print the movie  details of each professional
* according its type.
***********************************************************/
string Producers::printMyMovies(){
	Output output;
	string str;
	string retStr;
	vector<Movie*>::iterator it;
	for(it=(personalMovieList).begin(); it !=(personalMovieList).end(); ++it) {
		str=output.printMovie(*it);
		retStr=retStr+str;
	}
	return retStr;
}
/*******************************************************************
* the function addMovieToVector(Movie *movie) get a pointer to movie
* and add it to the private producer movie vector
*******************************************************************/
void Producers::addMovieToVector(Movie *movie){
	personalMovieList.push_back(movie);
}
/*******************************************************************
* distructor of Producers class
*******************************************************************/
Producers::~Producers(){}

