/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "Directors.h"

/***************************************************************
* constructor of Directors class,inherited from Professional's
* constructor.
****************************************************************/
Directors::Directors(string ID,string name,string specificDes,int age,
		             string gender):Professional( ID,name, specificDes,
		             age,gender){  }

/*****************************************************************
* The function printProfessional() implements the virtual
* printProfessional() function in the base class .
* the function print the professional details according its type.
******************************************************************/
string Directors::printProfessional(){
	return name;
}

/*******************************************************************
* the function addMovieToVector(Movie *movie) get a pointer to movie
* and add it to the private directors movie vector
*******************************************************************/
void Directors::addMovieToVector(Movie *movie){
	personalMovieList.push_back(movie);
}

/********************************************************************
* the function DeleteMovieFromVector(string code) receive the code
* of the movie which want to delete,and delete it from the
* private director movie vector.
*******************************************************************/
void Directors::DeleteMovieFromVector(string code){
	 vector<Movie*>::iterator it;
	 int result;
	 for(it=(personalMovieList).begin();it !=(personalMovieList).end();++it){
		 result=code.compare((*it)->getCode());
		 if(!result){
			 /*delete the movie*/
			 personalMovieList.erase(it);
			 break;
		 }
	 }
}
/*****************************************************************
* The function printMyMovies() implements the virtual
* printMyMovies() function in the base class .
* the function print the movie  details of each professional
* according its type.
******************************************************************/
string Directors::printMyMovies(){
	Output output;
	string str;
	string retStr;
	vector<Movie*>::iterator it;
	for(it=(personalMovieList).begin();it !=(personalMovieList).end();++it){
		str=output.printMovie(*it);
		retStr=retStr+str;
	}
	return retStr;
}
/*******************************************************************
* the function getNumOfMovies() return the number of movies
* the director participate at.
*******************************************************************/
int  Directors::getNumOfMovies(){
	return personalMovieList.size();
}
/*******************************************************************
* vector of all the movies which the director participate at
*******************************************************************/
Directors::~Directors(){}
