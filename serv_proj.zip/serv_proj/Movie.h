/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef MOVIE_H_
#define MOVIE_H_

#include <string>
#include <iostream>
#include <vector>
#include "Genre.h"
#include "Professional.h"
#include "SearchInVector.h"
#include "DecoratorSort.h"

using namespace std;

/*forward declaration */
class Genre;
class SearchInVector;
/**********************************************************
* The class Movie is represents the movie's structure, and
* contains functions that each movie can perform about himself.
* class SystemAdministrator is a friend of Movie class
***********************************************************/
class Movie{

	public:
		DecoratorSort dec;//object of the DecoratorSort class
		/******************************************************************
		* the function getSummery() return the movie summary
		*****************************************************************/
		string getSummery();
		/*****************************************************************
		* the function getYearOfPublic() return the movie's year of public
		*****************************************************************/
		int getYearOfPublic();
		/*****************************************************************
		* the function getRating() return the movie rating
		****************************************************************/
		double getRating();
		/*******************************************************************
		* Constructor Movie initialize the movie object by the constructor's
		* parameters .
		********************************************************************/
		Movie(string code, string nameOfMovie,double length,int yearOfPublic,
			  double rating,string summery);
		/*******************************************************************
		* constructor Movie(Movie *movie)  is an copy constructor,
		* getting a reference to movie and  make another movie which
		* is a copy of the reference movie.
		*******************************************************************/
		Movie(Movie *movie);
		/******************************************************************
		* the function returnGenreString() return the genre string
		*****************************************************************/
		string returnGenreString();

		/******************************************************************
		 * the function getCode() return the movie code
		 ******************************************************************/
		string getCode();
		/*******************************************************************
		 * The function getMovieName() return the movie name
		 ******************************************************************/
		string getMovieName();
		/*******************************************************************
		* The function operator+( Movie& other)  perform the + operator
		* between two pointers to movies object.the fuction get pointer to
		* other movie and add is to the movie which this function has called.
		* the function return a new movie* as a result
		********************************************************************/
		Movie operator+(Movie& other);
		/*******************************************************************
		* The function operator=( Movie movie)  perform the = operator as
		* assign movie into another movie .
		* ******************************************************************/
		void  operator=(Movie movie);
		/*******************************************************************
		* The function returnLongestMovie(Movie*other ) calculate the
		* longest movie between two movies and return a pointer to the
		* longest one.
		********************************************************************/
		Movie* returnLongestMovie(Movie* other);
		/*******************************************************************
		* The function unionProfessional( vector< Professional *> ProOther)
		* conceit between two vectors of professional * .the function get
		* professional vector of another movie .
		********************************************************************/
		void unionProfessional(vector< Professional *> ProOther);
		/*******************************************************************
		* The function unionGenre(genreOther: vector<Genre> genreOther
		* conceit between two vectors of Genre .the function get Genre
		* vector of another movie .
		*******************************************************************/
		void unionGenre(vector<Genre*> genreOther);
		/******************************************************************
		* The function deleteProFromMovie(int ID)  delete the professional
		* from the movie's professional list acoording its ID.
		*******************************************************************/
		void deleteProFromMovie(string ID);
		/******************************************************************
		 * The function searchProInMovie(int ID) search professional in the
		 * movie professional list by Id and return pointer to it
		 ******************************************************************/
		Professional* searchProInMovie(string ID);
		/******************************************************************
		* The function addProToMovie(Professional* pro)  get pointer to
		* professional and add it to the movie's MyProList vector.
		******************************************************************/
		void addProToMovie(Professional* pro);
		/*****************************************************************
		* The function void addGenreToMovie(String s) get a string of the
		* Genre and initialize the member Genre by it .
		*****************************************************************/
		void addGenreToMovie(Genre *genre);
		/********************************************************************
		 *  The function searchGenre(string genreString) search genre in the
		 * movie genre list by string and return the found genre
		 *******************************************************************/
		Genre* searchGenre(string genreString);
		/*********************************************************************
		* The function void deleteMovie() delete the movie which this function
		* has called to from the heap
		**********************************************************************/
		void deleteMovie(Movie* m);
		/*********************************************************************
		* The function sortProfessional(int kindOfSort) get input from user in
		* which way to sort the professional vector of the movie,and the
		* function sorted by it.
		*********************************************************************/
		void sortProfessional();
		/********************************************************************
		 * the function getLength() return the length of the movie
		 *******************************************************************/
		int getLength();
		/********************************************************************
		 * the function getProVector() return the professional vector of
		 * the movie
		 ********************************************************************/
		 vector<Professional*>& getProVector();
		 /*******************************************************************
		  * the function  getGenreVector() return the genre vector of the
		  * movie
		  ******************************************************************/
		 vector<Genre*>& getGenreVector();
		/*******************************************************************
		 * The function getTheProInIndex(int index) return a pointer to the
		 * professional in the i'th index
		 ******************************************************************/
		 Professional* getTheProInIndex(int index);
		 /*****************************************************************
		  * the function getValueToSearchBy() use to get
		  * the movie code string in the generic search function.
		  * the function return the movie code string
		  *****************************************************************/
		  string getValueToSearchBy();
		  /*******************************************************************
		  * Distructor of the Movie class
		  ******************************************************************/
		~Movie();

	private:

		vector<Genre*> genreList;
		vector<Professional*> MyProList;
		SearchInVector *s;
		string code;
		string nameOfMovie;
		double length;
		int yearOfPublic;
		double rating;
		string summery;



};

#endif
