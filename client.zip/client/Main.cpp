

/*
 * Main.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */
#define STOP "-1"
#define ARGSCOUNT 4
#include "UDPclient.h"
#include "TCPclient.h"


int main(int args, char *argv[]){

	Client* conn;
	int type;
	int port;
	string message;

	bool run = true;
	if(args!=4)
		cout<<"Error"<<endl;
	else{
		sscanf ((argv[1]), "%d",&type);//convert char* to int
		sscanf ((argv[3]), "%d",&port);//convert char* to int
		const int serverPort=port;//get the server port
		const char* ip_address =argv[2];

		if (type==1){
			conn= new TCPclient(ip_address,serverPort);
		} else {
			conn= new UDPclient(ip_address,serverPort);
		}

		conn->initialize();

		while(run){

			message = conn->getString();

			if(message==STOP){
				run= false;
			}
			else{
				conn->sendTo();
				conn->receivedFrom();
			}
		}

	}
	close(conn->getSock());
	return 0;
}


