/*
 * TCPclient.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#include "TCPclient.h"

TCPclient::TCPclient(const char* ip_address,
		int port_no):Client(ip_address,port_no){
	// TODO Auto-generated constructor stub

}

bool TCPclient::initialize(){
	if (connect(sock, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
				return false;
			}
	sock = socket(AF_INET, SOCK_STREAM, 0);
		if (sock < 0) {
			return	false;
		}

		return true;
}

bool TCPclient::sendTo(){

	int data_len = strlen(buffer);
	int sent_bytes = send(sock, buffer, data_len, 0);

	if (sent_bytes < 0) {
		return false;
	}
	return true;

}

bool TCPclient::receivedFrom(){

	int expected_data_len = sizeof(buffer);
	int read_bytes = recv(sock, buffer, expected_data_len, 0);
	if (read_bytes == 0) {
		// connection is closed
		return false;
	}
	else if (read_bytes < 0) {
		return false; // error
	}

	this->outPutMessage(buffer);
	return true;

}

TCPclient::~TCPclient() {
	// TODO Auto-generated destructor stub
}

