/*
 * TCPclient.h
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#ifndef TCPCLIENT_H_
#define TCPCLIENT_H_
#include "Client.h"

class TCPclient :public Client{
public:
	TCPclient(const char* ip_address,
			int port_no);

	bool sendTo();

	bool receivedFrom();

	bool initialize();

	virtual ~TCPclient();
};

#endif /* TCPCLIENT_H_ */
