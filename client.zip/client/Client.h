/*
 * Connection.h
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#ifndef CLIENT_H_
#define CLIENT_H_

#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>



using namespace std;

class Client {
protected:
	const char* ip_address;
	const int port_no;
	int sock;
	struct sockaddr_in sin;
	char buffer[4096];



public:
	Client(const char* ip_address,
			const int port_no);

	virtual ~Client();

	/*initialize the connection parameters
	 *return values: 1-"failure",0-"success"
	 */
	virtual bool initialize()=0;


	/*
	 * get char* from console
	 * return char*
	 */
	string getString();

	virtual bool sendTo()=0;

	virtual bool receivedFrom()=0;

	void outPutMessage(char* buffer);

	int getSock();

};

#endif /* CLIENT_H_ */
