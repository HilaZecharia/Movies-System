/*
 * UDPclient.h
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#ifndef UDPCLIENT_H_
#define UDPCLIENT_H_
#include "Client.h"

class UDPclient:public Client {

public:
	UDPclient(const char* ip_address,
			int port_no);

	virtual ~UDPclient();

	bool initialize();

	bool sendTo();

	bool receivedFrom();

};

#endif /* UDPCLIENT_H_ */
