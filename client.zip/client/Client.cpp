/*
 * Connection.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#include "Client.h"

Client::Client(const char* ip_address,
		int port_no):port_no(port_no) {

	this->ip_address=ip_address;
	this->sock=-1;
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr(ip_address);
	sin.sin_port = htons(port_no);

}





string Client:: getString(){
	string str;


	getline(cin, str);


	copy(str.begin(), str.end(), buffer);
	buffer[str.size()] = '\0'; // don't forget the terminating 0

	cout<< buffer<<endl;

	return str;
	// don't forget to free the string after finished using it
}

void Client::outPutMessage(char* buffer){
	cout << buffer;
}


int Client::getSock(){
	return this->sock;
}


Client::~Client() {
}

