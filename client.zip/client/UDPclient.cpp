/*
 * UDPclient.cpp
 *
 *  Created on: Dec 20, 2015
 *      Author: tal
 */

#include "UDPclient.h"


UDPclient::UDPclient(const char* ip_address,
		int port_no):Client(ip_address,port_no){

}

UDPclient::~UDPclient() {
	// TODO Auto-generated destructor stub
}

bool UDPclient::initialize(){

	sock = socket(AF_INET, SOCK_STREAM, 0);
		if (sock < 0) {
			return	false;
		}

		return true;

}

bool UDPclient::sendTo(){
	int sent_bytes = sendto(sock, buffer, strlen(buffer),
			0, (struct sockaddr *) &sin, sizeof(sin));
	if (sent_bytes < 0) {
		return false;
	}
	return true;
}

bool UDPclient::receivedFrom(){
	struct sockaddr_in from;
	unsigned int from_len = sizeof(struct sockaddr_in);
	memset(&buffer, 0, sizeof(buffer));
	int bytes = recvfrom(sock, buffer, sizeof(buffer), 0,
			(struct sockaddr *) &from, &from_len);
	if (bytes < 0) {
		return false;
	}
	this->outPutMessage(buffer);
	return  true;
}
