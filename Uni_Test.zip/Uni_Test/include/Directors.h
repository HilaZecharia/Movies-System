/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef DIRECTORS_H_
#define DIRECTORS_H_

#include <string>
#include <iostream>
#include <vector>
#include "Output.h"
using namespace std;
/**************************************************************
* The class Directors is derived class of class Professional .
* Class Directors represent the directors of the movies.
***************************************************************/
class Movie; /*forward daclaration */

class Directors:public Professional{
	public:

	    /***************************************************************
		* constructor of Directors class,inherited from Professional's
		* constructor.
		****************************************************************/
		Directors(string ID,string name,string specificDes,int age,string gender);
		/*****************************************************************
		* The function printProfessional() implements the virtual
		* printProfessional() function in the base class .
		* the function print the professional details according its type.
		******************************************************************/
		string printProfessional();
		/*****************************************************************
		* The function printMyMovies() implements the virtual
		* printMyMovies() function in the base class .
		* the function print the movie  details of each professional
		* according its type.
		******************************************************************/
		string printMyMovies();
		/*******************************************************************
		* the function getNumOfMovies() return the number of movies
		* the director participate at.
		*******************************************************************/
		 int  getNumOfMovies();
		 /*******************************************************************
		 * the function addMovieToVector(Movie *movie) get a pointer to movie
		 * and add it to the private directors movie vector
		 *******************************************************************/
		 void addMovieToVector(Movie *movie);
		 /********************************************************************
		 * the function DeleteMovieFromVector(string code) receive the code
		 * of the movie which want to delete,and delete it from the
		 * private director movie vector.
		 *******************************************************************/
		 void DeleteMovieFromVector(string code);
		/*****************************************************************
		 * distractor of the Directors class
		 ****************************************************************/
		~Directors();
	private:
		/*******************************************************************
		* vector of all the movies which the director participate at
		*******************************************************************/
		vector<Movie*> personalMovieList;
};

#endif
