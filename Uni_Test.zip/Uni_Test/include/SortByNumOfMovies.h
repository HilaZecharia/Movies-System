/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef SORTBYNUMOFMOVIES_H_
#define SORTBYNUMOFMOVIES_H_
#include "Professional.h"
#include "Sort.h"
/**************************************************************
 * the class SortByNumOfMovies inherited from Sort class and
 * implement the operator () according the professional movies
 * number
 **************************************************************/
class SortByNumOfMovies:public Sort {

	public:
	     /****************************************************************
		 * the function operator()(Professional *pro1,Professional *pro2)
		 * receive two pointers to professionals and compare between them
		 * by movies number, the function return true if pro1 movie number
		 * is smaller the pro2
		 * movies number ,and false otherwise .
		 *****************************************************************/
		bool operator()(Professional *pro1,Professional *pro2);
		/*******************************************************************
		* virtual distructor of the SortByNumOfMoviesclass
		******************************************************************/
		virtual ~SortByNumOfMovies();
};

#endif /* SORTBYNUMOFMOVIES_H_ */
