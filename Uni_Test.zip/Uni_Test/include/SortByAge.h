/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#ifndef SORTBYAGE_H_
#define SORTBYAGE_H_
#include "Professional.h"
#include "Sort.h"
/**************************************************************
 * the class SortByAge inherited from Sort class and implement
 * the operator () according the professional Age
 **************************************************************/
class SortByAge:public Sort {
        /****************************************************************
         * the function operator()(Professional *pro1,Professional *pro2)
         * receive two pointers to professionals and compare between them
         * by age, the function return true if pro1 age is bigger the pro2
         * age,and return false otherwise.
         *****************************************************************/
		bool operator()(Professional *pro1,Professional *pro2);
		/*******************************************************************
		 * virtual distructor of the SortByAge class
		 ******************************************************************/
		virtual ~SortByAge();
};

#endif /* SORTBYAGE_H_ */
