/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef INPUT_H_
#define INPUT_H_


#include <string>
#include <iostream>
#include <vector>
#include <stdlib.h>

using namespace std;
/***************************************************************
* The class Input getting all the inputs required from the user.
****************************************************************/
class Input{
	public:
	    /*****************************************************
	    * The function isTypeOfSortValid() check if the sort
	    * type valid,if it is return true else return false.
	    *****************************************************/
		bool isTypeOfSortValid();
		/*****************************************************
		* The function getSortBy() return the type of sort
		* the professionals of specific movie
		*****************************************************/
		int getSortBy();
		/*****************************************************
		* The function getMovieName() return the movie's name
		*****************************************************/
		string getMovieName();
		/*****************************************************
		* The function getMovieCode() return the movie's code
		*****************************************************/
		string getMovieCode();
		/*******************************************************
		* The function getGenreString() return the movie's genre
		*******************************************************/
		string getGenreString();
		/*******************************************************
		* The function getlength() return the movie's lenght
		*******************************************************/
		double getlength();
		/***********************************************************
		* The function getYearOfPublic() return the movie's public
		* year
		***********************************************************/
		int getYearOfPublic();
		/**********************************************************
		* The function getRating() return the movie rating
		***********************************************************/
		double getRating();
		/**********************************************************
		* The function getID() return the professional ID
		***********************************************************/
		string getID();
		/**********************************************************
		* The function getProName() return the professional name
		***********************************************************/
		string getProName();
		/**********************************************************
		* The function getSpecificDes() return the professional
		* specific description
		**********************************************************/
		string getSpecificDes();
		/*********************************************************
		* The function getAge() return the professional age
		*********************************************************/
		int getAge();
		/*********************************************************
		* The function getGender() return the professional gender
		*********************************************************/
		string getGender();
		/*********************************************************
		* The function getTypeOfPro() return the professional type
		*********************************************************/
		int getTypeOfPro();
		/***********************************************************
		 * The function getMovieSummery() return the movie's summary
		 **********************************************************/
		string getMovieSummery();
		/************************************************************
		* The function  callProInputFunc()  call all the professional
		* input functions
		*************************************************************/
		void callMovieInputFunc(string& copybuf);
		/************************************************************
		* The function  callProInputFunc()  call all the professional
		* input functions
		*************************************************************/
		void callProInputFunc(string& copybuf);
		/************************************************************
		* The function callToInputID() call the - inputID()
		************************************************************/
		void callToInputID(string& copybuf);
		/************************************************************
		* The function callToInputGenreString() call the -
		* inputGenreString()
		************************************************************/
		void callToInputGenreString(string& copybuf);
		/*************************************************************
		* The function callToInputMovieCode call the - inputMovieCode()
		**************************************************************/
		void callToInputMovieCode(string& copybuf);
		/***************************************************************
		 * The function isMovieLengthValid() check if the movie's length
		 * is valid ,if it is return true else return false
		 **************************************************************/
		bool isMovieLengthValid(double length);
		/***************************************************************
		* The function isMovieLengthValid() check if the movie's year
		* of public is valid ,if it is return true else return false
		**************************************************************/
		bool isYearOfPublicValid(int year);
		/***************************************************************
		* The function isMovieRatingValid() check if the movie's rating
		* is valid ,if it is return true else return false
		**************************************************************/
		bool isMovieRatingValid(double rating);
		/***************************************************************
		* The function isProAgeValid(int age) check if the professional's
		* age is valid ,if it is return true else return false
		**************************************************************/
		bool isProAgeValid(int age);
		/***************************************************************
		* The function isProAGenderValid(string gen) check if the
		* professional's gender is valid ,if it is return true else
		* return false
		**************************************************************/
		bool isProGenderValid(string gen);
		/**************************************************************
		 * the function setMovieCode(string codeOfMovie) receive code
		 * and set it in the codeOfMovie member.
		 **************************************************************/
		void setMovieCode(string codeOfMovie);
		/***************************************************************
		* The function isProTypeValid(int type) check if the professional
		* type is valid ,if it is return true else return false
		**************************************************************/
		bool isProTypeValid(int type);
		/**************************************************************
		 * the function setTypeOfSortToDeafult() set the default type
		 * of sorting the professionals  (sort by ID)
		 *************************************************************/
		void setTypeOfSortToDeafult();
		/**************************************************************
		 * the function InputUnitedMovies() return a string of all
		 * the movies we want to united in option number 8 .
		 *************************************************************/
		 string InputUnitedMovies(string& copybuf);
		 /**************************************************************
		 * the function InputSortBy() get from the input user the value
		 * of the sort.
		 **************************************************************/
		 void InputSortBy(string& copybuf);
		 /*************************************************************
		  * the function setMovieName(string s) receive a string s and
		  * initialize the nameOfMovie member by it.
		  ************************************************************/
		 void setMovieName(string s);
		 /**************************************************************
		 * Distructor of the Input class
		 **************************************************************/
		~Input();

	private:
		int selectedOption;
		string code;
		string nameOfMovie;
		double length;
		int yearOfPublic;
		double rating;
		string stringGener;
		string summary;
		string ID;
		string nameOfPro;
		string specificDes;
		int age;
		string gender;
		int typeOfPro;
		int sortBy;


		/****************************************************************
		* The function inputMovieName() get movie name from user
		*****************************************************************/
		void inputMovieName(string& copybuf);
		/*****************************************************************
		* The function inputMovieCode() get movie code from user
		******************************************************************/
		void inputMovieCode(string& copybuf);
		/*****************************************************************
		* The function  inputlength()  get movie length  from user
		*****************************************************************/
		void inputlength(string& copybuf);
		/*****************************************************************
		* The function inputYearOfPublic ()  get the movie's public year
		* from user
		*****************************************************************/
		void inputYearOfPublic(string& copybuf);
		/****************************************************************
		* The function inputRating() get the movie's rating from user
		*****************************************************************/
		void inputRating(string& copybuf);
		/****************************************************************
		* The function inputID()  get the professional ID from user
		******************************************************************/
		void inputID(string& copybuf);
		/*****************************************************************
		* The function inputProName() get the professional name from user
		******************************************************************/
		void inputProName(string& copybuf);
		/*****************************************************************
		* The function inputSpecificDes()   get the professional specific
		* description from user
		******************************************************************/
		void inputSpecificDes(string& copybuf);
		/*****************************************************************
		* The function  inputAge() get the professional age  from user
		******************************************************************/
		void inputAge(string& copybuf);
		/*****************************************************************
		* The function inputGenreString() get the movie's genre  from user
		******************************************************************/
		void inputGenreString(string& copybuf);
		/********************************************************************
		* The function inputTypeOfPro()  get the professional type from user
		*********************************************************************/
		void inputTypeOfPro(string& copybuf);
        /*******************************************************************
         * The function inputGender() get the professional gender from user
         ******************************************************************/
		void inputGender(string& copybuf);
		/*****************************************************************
		* The function inputSummary()) get the movie's summary from user
		******************************************************************/
		void inputSummary(string& copybuf);
};
#endif
