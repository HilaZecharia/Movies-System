/*
 * ServerTCP.h
 *
 *  Created on: Dec 17, 2015
 *      Author: hila
 */

#ifndef SERVERTCP_H_
#define SERVERTCP_H_

#include "Server.h"

#include <string>
#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>

using namespace std;

/**************************************************
 * the class ServerTCP inherite from Server class
 * and  perform the TCP server function
 **************************************************/
class ServerTCP:public Server {
public:
	/************************************************************
	* constructor of the ServerTCP class,inherited from Server
	* class constructor.
	* **********************************************************/
	ServerTCP(const int server_port);
	/************************************************************
	* the function creatSocket() create the socked descriptor for
	* the TCP server .if the socket create successfully return
	* true, else return false.
	* *********************************************************/
	bool creatSocket();
	/***********************************************************
	* the function readTheClientMassage() read the client
	* massage from the socket ,if the reading success return
	* true ,else return false.
	**********************************************************/
	bool readTheClientMassage();
	/************************************************************
	* the function sendToClient(string str) send the output
	* to the client by the socket.
	***********************************************************/
	void sendToClient(string str);
	/***********************************************************
	* the fucntion connectTheServer() calls the connection
	* server to socket function accorting the TCP protocol.
	**********************************************************/
	bool connectTheServer();
	/*distructor */
	 ~ServerTCP();
	 /***********************************************************
	 * the function acceptTheConnection() accepting the client's
	 * connection.if the acception sucsseed return true, else
	 * return false.
	 ************************************************************/
	bool acceptTheConnection();
private:
	struct sockaddr_in sin;
	struct sockaddr_in client_sin;
	int client_sock;

};

#endif /* SERVERTCP_H_ */
