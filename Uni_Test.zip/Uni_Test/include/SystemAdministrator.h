/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#ifndef SystemAdministrator_H_
#define SystemAdministrator_H_

#include <string>
#include <iostream>
#include <vector>
#include <cstring>
#include <sstream>
#include "Movie.h"
#include "Genre.h"
#include "Menu.h"
#include "Professional.h"
#include "Actress.h"
#include "Directors.h"
#include "Producers.h"
#include "ScreenWriters.h"
#include "SearchInVector.h"
#include "DecoratorSort.h"
#include "Input.h"
#include "Output.h"

using namespace std;

/*************************************************************************
* The class SystemAdministrator is in charge to manage the whole
* system. The class calls functions in order to perform the user's tasks.
* this class is a friend of class Movie.
**************************************************************************/

class SystemAdministrator{
	public:
		/***********************************************************
		* The StartToRun() function is responsible on kipping the
		* system running all the time in order to get user's
		* tasks and perform them .
		************************************************************/
		//void StartToRun();
		/*************************************************************
		* The function searchMovie(string movieCode) getting the code of
		* the selected movie  and search the movie in the vector
		* movieList ,if the movie found in the vector  the function
		* return pointer to it' otherwise return null
		**************************************************************/
		Movie*  searchMovie(string movieCode);
		/************************************************************
		* The function printAllMovies() iterate all the movies in the
		* system and printing them to the standard output.
		*************************************************************/
		string printAllMovies();
		/***************************************************************
		* The function CheckIfMovieCodeValid(string code) check if the
		* movie's code is valid ,if it is return true else return false
		**************************************************************/
		bool CheckIfMovieCodeValid(string code);
		/***************************************************************
		* The function checkIfGenreIsvalid(string genreString) check if
		* the movie's genre is valid ,if it is return true else return
		* false
		**************************************************************/
		bool checkIfGenreIsvalid(string genreString);
		/***************************************************************
		* The function CheckIfProIDValid(string id) check if the
		* professional ID is valid ,if it is return true else return
		* false
		**************************************************************/
		bool CheckIfProIDValid(string id);
		/************************************************************
		* The function printAllProffession() iterate all the
		* professional in the system and printing  them to the
		* standard output.
		*************************************************************/
		string printAllProffession();
		/**************************************************************
		* The function printProfessional(string ID) printing a specific
		* professional according the professional ID  from user.
		***************************************************************/
		void printProfessional(string ID);
		/*************************************************************
		* The function  searchProfessional(string ID) getting the ID of
		* the selected professional and search the professional in the
		* vector professionList ,if the professional found in the
		* vector the function return pointer to it,otherwise return
		* null
		************************************************************/
		Professional* searchProfessional(string ID);
		/*************************************************************
		* The function searchGenre(string genreString) getting the genre
		* of the selected genre and search the genre in the
		* vector pgenreList ,if the genre found in the
		* vector the function return pointer to it, otherwise return
		* null
		************************************************************/
		Genre* searchGenre(string genreString);
		 /************************************************************
		 * distructor of the SystemAdministrator class
		 ************************************************************/
		~SystemAdministrator();
		/****************************************************************
		* The function runOption(int selectedOption)  getting the
		* selected option from user and calls the functions who implement
		*  the task which he user select.
		*****************************************************************/
		string runOption(int selectedOption,string buffer);
		/****************************************************************
		* The function createNewMovie() create dynamic allocation of Movie
		* object,initialize it by the user input and return a pointer to it
		*****************************************************************/
		Movie* createNewMovie();
		/****************************************************************
		* The function addNewMovie(Movie *m) receive a pointer to movie
		*  add the pointer into a  vector of type Movie*
		*****************************************************************/
		void addNewMovie(Movie *m);
		/*****************************************************************
		* The function addNewProfessional(Professional *pro) receive a
		* pointer to professional and add the pointer into a vector of
		* type Professional *
		******************************************************************/
		void addNewProfessional(Professional *pro);
		/*****************************************************************
		* The function createNewProfessional() create dynamic allocation of
		* professional object,initialize it by the user input and return a
		* pointer to it
		******************************************************************/
		Professional* createNewProfessional();
		/******************************************************************
		* The function addUnitedMovie(Movie* m) getting a movie which
		* is result of two movies and add it to the vector of type  movie*
		*******************************************************************/
		void addUnitedMovie(Movie* movie);
		/*******************************************************************
		* The function deleteMovie(string movieCode),delete a specific movie
		* from the list and from the heap.
		*******************************************************************/
		void deleteMovie(string movieCode);
		/******************************************************************
		* The function deleteProfessional( string ID) delete a specific
		* professional from the list and from the heap.
		*******************************************************************/
		void deleteProfessional(string ID);
		/******************************************************************
		* The function deleteProFromMovieList(string ID) delete a specific
		* professional from the  movie professional list .
		*******************************************************************/
		void deleteProFromMovieList(string ID);
		/******************************************************************
		* The function addGenre(string genreString) receive a genre string ,
		* create dynamicaly genre and add it to the genre vector
		*******************************************************************/
		Genre* addGenre(string genreString);
		/******************************************************************
		* The function deleteMovieFromGenreList(string code) receive the
		* movie code which we want to delete , and remove the movie from the
		* genre movie vector (in class Movie).
		*******************************************************************/
		void deleteMovieFromGenreList(string code);
		/******************************************************************
		* The function deleteMovieFromProList(string code) receive the
		* movie code which we want to delete , and remove the movie from the
		* professional movie vector.
		*******************************************************************/
		void deleteMovieFromProList(string code);
		/*******************************************************************
		 * the function createUnitedMovie( vector<string>& vectorString)
		 * receive a vector of string which contains the movie code of all
		 * the movies we want to united, and create from them the united movie.
		 * the function return a pointer to the united movie
		 ********************************************************************/
		Movie* createUnitedMovie(vector<string>& vectorString);
		/*********************************************************************
		 * the function IsUnionMoviesValid(vector<string>& vectorString,string str)
		 * check for each movie we want to united if its code valid (exist in the
		 * system) if it is return true ,otherwise return false.
		 **********************************************************************/
		bool IsUnionMoviesValid( vector<string>& vectorString, string str);
	private:
			SearchInVector s;
			Input input;
			Output output;
			DecoratorSort sd;
			Menu men;
			vector<Movie*>  movieList;
			vector< Professional* > professionalList;
			vector< Genre* > GenreList;

};
#endif
