

#ifndef SHAREDTCPANDUDP_H_
#define SHAREDTCPANDUDP_H_
/*abstact class*/
/************************************************
 * the class SharedTCPAndUDP is an abstract class
 * which has a virtual creatSocket function that
 * the drived class implements.
 ***********************************************/
class SharedTCPAndUDP {
public:

	/*****************************************************
	 * the function  creatSocket() is a pure virtual
	 * function that the drived classes implement.
	 * the function return true is the socked descriptor
	 * created succesefully,otherwise return false
	 ****************************************************/
	virtual  bool creatSocket()=0;
	/*distructor */
	virtual ~SharedTCPAndUDP(){ };

};

#endif /* SHAREDTCPANDUDP_H_ */
