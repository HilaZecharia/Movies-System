

#ifndef SERVER_H_
#define SERVER_H_

#include "SharedTCPAndUDP.h"
#include "Menu.h"
#include "SystemAdministrator.h"


#include <iostream>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>


using namespace std;
/****************************************************************
 * the class Server inheritance from class SharedTCPAndUDP .
 * the Server class perform as interfase of server object of any
 * type.
 ***************************************************************/
class Server:public SharedTCPAndUDP {
public:
	/************************************************************
	 * constructor of the server class
	 * *********************************************************/
	 Server(const int& server_port);
	/************************************************************
	 * the function creatSocket() create the socked descriptor
	 * if the socket create successfully return true, else
	 * return false.
	 * *********************************************************/
	 virtual  bool creatSocket();
	 /***********************************************************
	  * the fucnction doBind() binding the socked to the server
	  * port.if the binding succses return true,else return false.
	  * ********************************************************/
	 bool doBind();
	 /***********************************************************
	  * the function readTheClientMassage() read the client
	  * massage from the socket ,if the reading success return
	  * true ,else return false.
	  **********************************************************/
	 virtual bool readTheClientMassage();
	 /************************************************************
	  * the function sendToClient(string str) send the output
	  * to the client by the socket.
	  ***********************************************************/
	 virtual void sendToClient(string str);
	 /***********************************************************
	  * the fucntion connectTheServer() calls the connection
	  * server to socket function accorting the server type.
	  **********************************************************/
	 virtual bool connectTheServer();
	 /***********************************************************
	 * The StartServer(Server *server) function is responsible on
	 * keeping the server running all the time in order to get
	 * client's commands and perform them .
	 ************************************************************/
	 void StartServer(Server *server);
     /*distructor */
	 virtual ~Server();

protected:
	char buffer[4096];//the buffer contains the massage
	struct sockaddr_in sin;
	int sock;

};

#endif /* SERVER_H_ */
