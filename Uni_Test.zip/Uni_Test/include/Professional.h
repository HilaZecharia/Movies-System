/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef PROFESSIONAL_H_
#define PROFESSIONAL_H_

#include <string>
#include <iostream>
#include <vector>



using namespace std;
/***************************************************************************
* The class Professional is a base class of the all professionals' objects.
* Professional is represents the Professional 's structure.
*the class inherited its members and function to the professionals derived
*the class.the Professional class has two virtual functions which the derived
*the classes implements
****************************************************************************/
class Movie;


class Professional{
	public:

        /********************************************************************
         * constructor That initialize the professional object
         * by the user input
         ********************************************************************/
		Professional(string ID,string name,string specificDes,int age,
				     string gender);
		/********************************************************************
		 * the function deletePro(Professional *pro) receive a pointer to
		 * the professional which we wand to delete and delete it from the memory
		 **********************************************************************/
		void deletePro(Professional *pro);
		/********************************************************************
		* The function printProfessional() is a virtual function that the
		* derived class implements. The purpose of this function in to print
		* the professional according it type.
		*********************************************************************/
		virtual string  printProfessional();
		/*********************************************************************
		* The function printMyMovies()is a virtual function that the derived
		* class implements. The purpose of this function in to print the movies
		* of each professional according his type.
		**********************************************************************/
		virtual string  printMyMovies();
		/********************************************************************
		 * The function getID() return the professional ID
		 ********************************************************************/
		string getID();
		/********************************************************************
		* The function getValueToSearchBy() use to get the professional
		* ID in the generic search function. the function return the
		* ID string of the current professional.
		********************************************************************/
		string getValueToSearchBy();
		/********************************************************************
		 * the function getAge() return the professional's age
		 *******************************************************************/
		int getAge();
		/*******************************************************************
		 * the function getName() return the name of the professional
		 ******************************************************************/
		string getName();
		/******************************************************************
		 * the function getSpecificDes() return the spcific description of the
		 * professional according its type
		 ******************************************************************/
		string getSpecificDes();
        /********************************************************************
         * the function getNumOfMovies() is a virtual function which
         * return the number of movie that each professional participate at
         ********************************************************************/
		virtual int  getNumOfMovies();
		/*********************************************************************
		 * the function addMovieToVector(Movie* movie)  is a
		 * virtual function which receive a pointer
		 * to movie and add it to the private professional movies vector
		 *********************************************************************/
		virtual void addMovieToVector(Movie* movie);
		/********************************************************************
		 * the function DeleteMovieFromVector(string code) is a virtual
		 * function which receive the code of movie we want to delete
		 * and delete it from the private movies vector in the derived classes
		 *********************************************************************/
		virtual void DeleteMovieFromVector(string code);
		/********************************************************************
		 * Distructor of the Professional class
		 ********************************************************************/
		virtual ~Professional();

	protected:

		string ID;
		string name;
		string specificDes;
		int age;
		string gender;

};
#endif
