/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#ifndef SORTBYID_H_
#define SORTBYID_H_
#include "Professional.h"
#include "Sort.h"
/**************************************************************
 * the class SortByID inherited from Sort class and implement
 * the operator () according the professional ID
 **************************************************************/
class SortByID:public Sort
{
	public:
	 /****************************************************************
	 * the function operator()(Professional *pro1,Professional *pro2)
	 * receive two pointers to professionals and compare between them
	 * by ID, the function return true if pro1 ID is smaller the pro2
	 * ID,and false otherwise .
	 *****************************************************************/
	 bool operator()(Professional *pro1,Professional *pro2);
	 /*******************************************************************
	 * virtual distructor of the SortByID class
	 ******************************************************************/
		virtual ~SortByID();
};

#endif /* SORTBYID_H_ */
