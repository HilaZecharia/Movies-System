/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#ifndef SORT_H_
#define SORT_H_
#include "Professional.h"
/*****************************************************************
 * the class Sort is an abstract class which perform overloading
 * the operator () for the sort function
 ****************************************************************/
class Sort {

public:

    /***************************************************************
     * the function operator()(Professional *pro1,Professional *pro2)
     * is a virtual function that overload the operator (), and every
     * derived class that inherited Sort class implement the function
     ****************************************************************/
	virtual bool operator()(Professional *pro1,Professional *pro2)=0;
    /****************************************************************
     *virtual distructor of the Sort class
     ****************************************************************/
	virtual ~Sort(){ }
};

#endif
