/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef MENU_H_
#define MENU_H_

#include <string>
#include <iostream>
#include <vector>
#include <string.h>
#include <stdio.h>
#include <cstring>


using namespace std;
/*******************************************************************
* The class Menu represent the menu of the system ,which display to
* the user each time he want to select a task to perform.
********************************************************************/
class Menu{
	public:
		/****************************************************************
		* The function  selectOption() get from user a selected option
		* in order to perform it .the function return the selected option
		* to the system.
		*****************************************************************/
		int selectOption(string& buf);
		/****************************************************************
		 * The function isOptionValid(int selectOption) check if the
		 * option is valid, if it is  return true else ,return false
		 ***************************************************************/
		bool isOptionValid(int selectOption);
		/****************************************************************
		 * the function void setOption(int op) set the option member by
		 * the value from the user
		 ***************************************************************/
		void setOption(int op);
		/***************************************************************
		 * The function int getOption() return the option
		 **************************************************************/
		int getOption();
		/***************************************************************
		 * Distructor of the Menu class
		 **************************************************************/
		~Menu();
	private:
		int option;

};
#endif
