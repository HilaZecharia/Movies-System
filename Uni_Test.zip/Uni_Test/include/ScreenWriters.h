/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#ifndef SCREENWRITERS_H_
#define SCREENWRITERS_H_

#include <string>
#include <iostream>
#include <vector>
#include "Movie.h"
#include "Output.h"
using namespace std;
/****************************************************************
* The class ScreenWriters is derived class of class Professional
* Class Directors represent the ScreenWriters of the movies.
*****************************************************************/
class ScreenWriters:public Professional{
	public:
	   /*****************************************************************
	   * constructor of  ScreenWriters class,inherited from Professional's
	   * constructor.
	   ****************************************************************/
	   ScreenWriters(string ID,string name,string specificDes,int age,
			         string gender);
		/************************************************************
		* The function printProfessional() implements the virtual
		* printProfessional() function in the base class .
		* the function print the professional details
		* according its type.
		*************************************************************/
		string printProfessional();
		/************************************************************
		* The function printMyMovies() implements the virtual
		* printMyMovies() function in the base class .
		* the function print the movie  details of each professional
		* according its type.
		*************************************************************/
		string printMyMovies();
		/*******************************************************************
		* the function getNumOfMovies() return the number of movies
		* the ScreenWriters participate at.
		*******************************************************************/
		int  getNumOfMovies();
		/*******************************************************************
		* the function addMovieToVector(Movie *movie) get a pointer to movie
		* and add it to the private ScreenWriters movie vector
		*******************************************************************/
		void addMovieToVector(Movie *movie);
		/********************************************************************
		* the function DeleteMovieFromVector(string code) receive the code
		* of the movie which want to delete,and delete it from the
		* private ScreenWriters movie vector.
		*******************************************************************/
		void DeleteMovieFromVector(string code);
		/************************************************************
		 * Distructor of the ScreenWriters class
		 ************************************************************/
		~ScreenWriters();
	private:
		/*******************************************************************
		* vector of all the movies which the screenWriter participate at
		*******************************************************************/
		vector<Movie*> personalMovieList;
};
#endif
