/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "SortByNumOfMovies.h"
/****************************************************************
* the function operator()(Professional *pro1,Professional *pro2)
* receive two pointers to professionals and compare between them
* by movies number, the function return true if pro1 movie number
* is smaller the pro2
* movies number ,and false otherwise .
*****************************************************************/
bool SortByNumOfMovies::operator()(Professional *pro1,Professional *pro2) {
	int num1,num2;
	num1=pro1->getNumOfMovies();
	num2=pro2->getNumOfMovies();
	/*if pro 1 has move movies which he participate at */
	if(num1<num2)
		return false;
	/*if pro 2 has move movies which he participate at */
	else
		return true;
}
/*******************************************************************
* virtual distructor of the SortByNumOfMoviesclass
******************************************************************/
SortByNumOfMovies::~SortByNumOfMovies() {

}
