/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "Input.h"
#include "SystemAdministrator.h"
#define THREE 3
#define ONE 1
#define ZERO 0
#define TEN 10
#define MAX_YEAR 2015
#define MAX_AGE 120
#define MALE "male"
#define FEMALE "female"
#define SPACE " "


/***************************************************************
* The function isProAgeValid(int age) check if the professional's
* age is valid ,if it is return true else return false
**************************************************************/
bool Input::isProAgeValid(int age){
	if(age>=ZERO && age<=MAX_AGE)
		return true;
	return false;
}
/***************************************************************
* The function isProGenderValid(string gen) check if the
* professional's gender is valid ,if it is return true else
* return false
**************************************************************/
bool Input::isProGenderValid(string gen){
	int female,male;
	female=gen.compare(FEMALE);
	male=gen.compare(MALE);
	if(female==ZERO || male==ZERO )
		return true;
	return false;
}
/***************************************************************
* The function isProTypeValid(int type) check if the professional
* type is valid ,if it is return true else return false
**************************************************************/
bool Input::isProTypeValid(int type){
	if(type>=ZERO && type<=THREE)
		return true;
	return false;
}
/*****************************************************
* The function getMovieName() return the movie's name
*****************************************************/
string Input::getMovieName(){
	return nameOfMovie;
}
/*****************************************************
* The function getMovieCode() return the movie's code
*****************************************************/
string Input:: getMovieCode(){
	return code;
}
/*******************************************************
* The function getGenreString() return the movie's genre
*******************************************************/
string Input::getGenreString(){
	return stringGener;
}
/*******************************************************
* The function getlength() return the movie's lenght
*******************************************************/
double Input::getlength(){
	return length;
}
/***********************************************************
* The function getYearOfPublic() return the movie's public
* year
***********************************************************/
int Input::getYearOfPublic(){
	return yearOfPublic;
}
/**************************************************************
* the function InputSortBy() get from the input user the value
* of the sort.
**************************************************************/
void Input::InputSortBy(string& copybuf){
	int num;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string sortNum = copybuf.substr(0, at); // token is "scott"
	sscanf (sortNum .c_str(), "%d",&num);//convert string to int
	copybuf=copybuf.substr(at+1);//the copybuf not contains the movie length anymore
	sortBy=num;
}
/*****************************************************
* The function isTypeOfSortValid() check if the sort
* type valid,if it is return true else return false.
*****************************************************/
bool Input::isTypeOfSortValid(){
	if(sortBy>=ZERO && sortBy<=THREE)
		return true;
	else
		return false;
}
/*****************************************************
* The function getSortBy() return the type of sort
* the professionals of specific movie
*****************************************************/
int Input::getSortBy(){
	return sortBy;
}
/**********************************************************
* The function getRating() return the movie rating
***********************************************************/
double Input::getRating(){
	return  rating;
}
/**********************************************************
* The function getID() return the professional ID
***********************************************************/
string Input::getID(){
	return ID;
}
/**********************************************************
* The function getProName() return the professional name
***********************************************************/
string Input::getProName(){
	return nameOfPro;
}
/**********************************************************
* The function getSpecificDes() return the professional
* specific description
**********************************************************/
string Input::getSpecificDes(){
	return specificDes;
}
/*************************************************************
* the function setMovieName(string s) receive a string s and
* initialize the nameOfMovie member by it.
************************************************************/
void Input::setMovieName(string s){
	nameOfPro=s;
}
/*********************************************************
* The function getAge() return the professional age
*********************************************************/
int Input::getAge(){
	return age;
}
/*********************************************************
* The function getGender() return the professional gender
*********************************************************/
string Input::getGender(){
	return gender;
}
/*********************************************************
* The function getTypeOfPro() return the professional type
*********************************************************/
int Input::getTypeOfPro(){
	return typeOfPro;
}
/***********************************************************
 * The function getMovieSummery() return the movie's summary
 **********************************************************/
string Input::getMovieSummery(){
	return summary;
}
/************************************************************
* The function  callProInputFunc()  call all the professional
* input functions
*************************************************************/
void Input::callMovieInputFunc(string& copybuf){

	 inputMovieCode(copybuf);
	 inputMovieName(copybuf);
	 inputlength(copybuf);
	 inputYearOfPublic(copybuf);
	 inputRating(copybuf);
	 inputSummary(copybuf);
	 setTypeOfSortToDeafult();

}
/*****************************************************************
* The function inputGenreString() get the movie's summary from user
******************************************************************/
void Input::inputSummary(string& copybuf ){
    cout<<"@"<<copybuf<<endl;
	summary=copybuf;
}
/************************************************************
* The function  callProInputFunc()  call all the professional
* input functions
*************************************************************/
void Input::callProInputFunc(string& copybuf){
	inputTypeOfPro(copybuf);
	inputID(copybuf);
	inputAge(copybuf);
	inputSpecificDes(copybuf);
	inputGender(copybuf);
	inputProName(copybuf);
}
/************************************************************
* The function callToInputID() call the - inputID()
************************************************************/
void Input::callToInputID(string& copybuf){
	inputID(copybuf);
}
/************************************************************
* The function callToInputGenreString() call the -
* inputGenreString()
************************************************************/
void Input::callToInputGenreString(string& copybuf){
	inputGenreString(copybuf);
}
/*************************************************************
* The function callToInputMovieCode call the - inputMovieCode()
**************************************************************/
void Input::callToInputMovieCode(string& copybuf){
	inputMovieCode(copybuf);
}
/****************************************************************
* The function inputMovieName() get movie name from user
*****************************************************************/
void Input::inputMovieName(string& copybuf){

	  string delimiter =SPACE;
	  int at=copybuf.find(delimiter);
	  string MovieName = copybuf.substr(0, at); // token is "scott"
	  nameOfMovie=MovieName;
	  copybuf=copybuf.substr(at+1);//the copybuf not contains the movie name anymore

}
/*****************************************************************
* The function inputMovieCode() get movie code from user
******************************************************************/
void Input::inputMovieCode(string& copybuf){
	  string delimiter =SPACE;
	  int at=copybuf.find(delimiter);
	  string MovieCode = copybuf.substr(0, at); // token is "scott"
	  code=MovieCode;
	  copybuf=copybuf.substr(at+1);//the copybuf not contains the movie name anymore
}
/*****************************************************************
* The function  inputlength()  get movie length  from user
*****************************************************************/
void Input::inputlength(string& copybuf){

	double MovieLength;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string len = copybuf.substr(0, at); // token is "scott"
	MovieLength = strtod(len.c_str(), NULL);//convert the string to double
	copybuf=copybuf.substr(at+1);//the copybuf not contains the movie length anymore
	length=MovieLength;
}
/*****************************************************************
* The function inputYearOfPublic ()  get the movie's public year
* from user
*****************************************************************/
void Input::inputYearOfPublic(string& copybuf){
	int year;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string yearOf = copybuf.substr(0, at); // token is "scott"
	sscanf (yearOf.c_str(), "%d",&year);//convert string to int
	copybuf=copybuf.substr(at+1);//the copybuf not contains the movie length anymore
	yearOfPublic=year;
}
/****************************************************************
* The function inputRating() get the movie's rating from user
*****************************************************************/
void Input::inputRating(string& copybuf){
	double rate;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string rat = copybuf.substr(0, at); // token is the year
	rate = strtod(rat.c_str(), NULL);//convert the string to double
	copybuf=copybuf.substr(at+1);//the copybuf not contains the movie length anymore
	rating=rate;
}
/****************************************************************
* The function inputID()  get the professional ID from user
******************************************************************/
void Input::inputID(string& copybuf){

	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string ProID = copybuf.substr(0, at); // token is the year
	copybuf=copybuf.substr(at+1);//the copybuf not contains the id anymore
	ID=ProID;
}
/*****************************************************************
* The function inputProName() get the professional name from user
******************************************************************/
void Input::inputProName(string& copybuf){

		nameOfPro=copybuf;
}
/*****************************************************************
* The function inputSpecificDes()   get the professional specific
* description from user
******************************************************************/
void Input::inputSpecificDes(string& copybuf){
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string des = copybuf.substr(0, at); // token is the description
	copybuf=copybuf.substr(at+1);//the copybuf not contains the id anymore
	specificDes=des;
}
/*****************************************************************
* The function  inputAge() get the professional age  from user
******************************************************************/
void Input::inputAge(string& copybuf){
	int proAge;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string professAge = copybuf.substr(0, at); // token is the pro age
	sscanf (professAge.c_str(), "%d",&proAge);//convert string to int
	copybuf=copybuf.substr(at+1);//the copybuf not contains the pro age anymore
	age=proAge;
}
/*****************************************************************
* The function inputGenreString() get the movie's genre  from user
******************************************************************/
void Input::inputGenreString(string& copybuf){

	stringGener=copybuf;
}
/********************************************************************
* The function inputTypeOfPro()  get the professional type from user
*********************************************************************/
void Input::inputTypeOfPro(string& copybuf){
	int type;
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string professType = copybuf.substr(0, at); // token is the pro type
	sscanf (professType.c_str(), "%d",&type);//convert string to int
	copybuf=copybuf.substr(at+1);//the copybuf not contains the pro type anymore
	typeOfPro=type;

}
/*******************************************************************
* The function inputGender() get the professional gender from user
********************************************************************/
void Input::inputGender(string& copybuf){
	string delimiter =SPACE;
	int at=copybuf.find(delimiter);
	string gen = copybuf.substr(0, at); // token is the gender
	copybuf=copybuf.substr(at+1);//the copybuf not contains the pro gender anymore
	gender=gen;
}
/***************************************************************
* The function isMovieLengthValid() check if the movie's length
* is valid ,if it is return true else return false
**************************************************************/
bool Input::isMovieLengthValid(double length){
	if(length>ZERO)
		return true;
	return false;
}
/**************************************************************
* The function isMovieLengthValid() check if the movie's year
* of public is valid ,if it is return true else return false
**************************************************************/
bool Input::isYearOfPublicValid(int yearOfPublic ){
	if(yearOfPublic>=ZERO && yearOfPublic<=MAX_YEAR)
		return true;
	return false;
}
/**************************************************************
* the function InputUnitedMovies() return a string of all
* the movies we want to united in option number 8 .
*************************************************************/
string Input::InputUnitedMovies(string& copybuf){
	string strInput=copybuf;
	/*
	getline(cin,strInput);
	if(strInput[ZERO]==' ')
		strInput=strInput.substr(ONE);
    */
	return strInput;
}

/***************************************************************
* The function isMovieRatingValid() check if the movie's rating
* is valid ,if it is return true else return false
**************************************************************/
bool Input::isMovieRatingValid(double rating){
	if(rating>=ZERO && rating<=TEN)
		return true;
	return false;
}
/*************************************************************
* the function setMovieName(string s) receive a string s and
* initialize the nameOfMovie member by it.
************************************************************/
void Input::setTypeOfSortToDeafult(){
	sortBy=ZERO;
}
/**************************************************************
* the function setMovieCode(string codeOfMovie) receive code
* and set it in the codeOfMovie member.
**************************************************************/
void Input::setMovieCode(string codeOfMovie){
	code=codeOfMovie;
}
/**************************************************************
* Distructor of the Input class
**************************************************************/
Input::~Input(){ }
