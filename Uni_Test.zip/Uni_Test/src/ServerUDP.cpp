/*
 * ServerUDP.cpp
 *
 *  Created on: Dec 16, 2015
 *      Author: hila
 */

#include "ServerUDP.h"

/************************************************************
* constructor of the ServerUDP class,inherited from Server
* class constructor.
* **********************************************************/
ServerUDP::ServerUDP(const int server_port):Server(server_port){

}
/***********************************************************
* the fucntion connectTheServer() calls the connection
* server to socket function accorting the UDP protocol.
**********************************************************/
bool ServerUDP::connectTheServer(){
	if(creatSocket()==false)
		return false;// if the secket not created succesfuly
	if(doBind()==false)
		return false;

	return true;

}
/***********************************************************
* the function readTheClientMassage() read the client
* massage from the socket ,if the reading success return
* true ,else return false.
**********************************************************/
bool ServerUDP::readTheClientMassage(){
	unsigned int from_len = sizeof(struct sockaddr_in);
	memset(&buffer, 0, sizeof(buffer));
	int bytes = recvfrom(sock, buffer, sizeof(buffer), 0, (struct sockaddr *) &from, &from_len);

	if (bytes < 0) {
	    perror("error reading from socket");
	    return false;
	}

	return true;
}
/************************************************************
* the function sendToClient(string str) send the output
* to the client by the socket.
***********************************************************/
void ServerUDP::sendToClient(string str){
	int bytes=str.length();
	memset(&buffer, 0, sizeof(buffer));

	/*convert the string to array*/
	strcpy(buffer, str.c_str());

	int sent_bytes = sendto(sock, buffer, bytes, 0, (struct sockaddr *) &from, sizeof(from));
	if (sent_bytes < 0) {
		perror("error writing to socket");
	}

}
/************************************************************
* the function creatSocket() create the socked descriptor for
* the TCP server .if the socket create successfully return
* true, else return false.
* *********************************************************/
bool ServerUDP::creatSocket(){

        //the udp server create the socket
	    sock = socket(AF_INET, SOCK_DGRAM,0);

	    if (sock < 0) {
	        perror("server: error creating udp socket");
	        return false;
	    }
	    return true;

}
/*distructor */
ServerUDP::~ServerUDP() {

}

