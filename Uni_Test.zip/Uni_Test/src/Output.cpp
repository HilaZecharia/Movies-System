#include "Output.h"
#define  SUCCESS "Success\n"
#define FAILURE "Failure\n"

/********************************************************
* the function printSuccess() print "success" to stdout
*******************************************************/
string Output::printSuccess(){
	return SUCCESS;

}
/********************************************************
* the function  printFailure() print "failure" to stdout
*******************************************************/
string Output::printFailure(){
	return FAILURE;

}
/*******************************************************
* the function printMovie(Movie *movie) receive  a
* pointer to specific movie and print it details
******************************************************/
string Output::printMovie(Movie *movie){
    string retStr;
	/*get the movie parameters*/

	string str=movie->returnGenreString();
	string code=movie->getCode();
	string nameOfMovie=movie->getMovieName();
	double length=movie->getLength();
	int yearOfPublic=movie->getYearOfPublic();
	double rating=movie->getRating();
	string summery=movie->getSummery();
	string strLength;
	string strYear;
	string strRate;
	ostringstream convert;   // stream used for the conversion

	convert << length;
	strLength = convert.str(); // set 'length' to the contents of the stream
	convert.str(""); //clear the convert stream
	convert.clear();
	convert << yearOfPublic;
	strYear=convert.str();
	convert.str("");
	convert.clear();
	convert << rating;
	strRate=convert.str();
	convert.str("");
	convert.clear();
	if(str!="")//if there is genre to the movie
		retStr=code+" "+nameOfMovie+" "+strLength+" "+strYear+" "+strRate+" "+str+
		       " "+summery+'\n';
	else
		retStr=code+" "+nameOfMovie+" "+strLength+" "+strYear+" "+strRate+" "+summery+'\n';

/*
	retStr=code+" "+nameOfMovie+" "+strLength+" "+strYear+" "+strRate
			+str+" "+summery+'\n';
			*/
	/*print the movie's professionals*/
	retStr=retStr+printMoviePro(movie);
	return retStr;

}


string Output::printPro(Professional *pro){
	string proOutput;
	proOutput=(pro->printProfessional())+'\n';

	return proOutput;
}
/*****************************************************************
* The function printMoviePro(Movie *movie) print the personal
* professional list the  movie which send as a parameter.
*******************************************************************/
string Output::printMoviePro(Movie *movie){
	string proOutput;
	string str;

	movie->sortProfessional();//sorting the professionals before print them
	/*intarate the movie  professional vector */
	vector<Professional*>::iterator it;
	vector<Professional*> MovieProList=movie->getProVector();
	for(it=( MovieProList).begin();it!=( MovieProList).end();++it){
		proOutput=(*it)->printProfessional();

		str=str+proOutput+'\n';
	}
	return str;

}
