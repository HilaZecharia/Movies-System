/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "SystemAdministrator.h"
#define ACTRESS 1
#define DIRECTOR 0
#define PRODUCER 3
#define SCREEN_WRITER 2
#define ZERO 0
#define STOP_RUNING -1


/************************************************************
* The function printAllMovies() iterate all the movies in the
* system and printing them to the standard output.
*************************************************************/
string SystemAdministrator:: printAllMovies(){
	string str;
	string retStr;
	vector<Movie*>::iterator it;
	for(it=(movieList).begin(); it !=(movieList).end();++it) {
		/*print the movie details */
		str=output.printMovie(*it);
		retStr=retStr+str;
	}
	return retStr;
}
/************************************************************
* The function printAllProffession() iterate all the
* professional in the system and printing  them to the
* standard output.
*************************************************************/
string SystemAdministrator::printAllProffession(){
	string str;
	string retStr;
	vector<Professional*>::iterator it;
	for(it=(professionalList).begin();it !=(professionalList).end();++it){
		str=output.printPro(*it);
		retStr=retStr+str;
	}
	return retStr;
}
/****************************************************************
* The function runOption(int selectedOption)  getting the
* selected option from user and calls the functions who implement
*  the task which he user select.
*****************************************************************/
string SystemAdministrator::runOption(int selectedOption,string copybuf){

	string returnString;
	Professional *pro;
	Movie *movie;
	Genre *genre;
	string stri;
	string& refStr= copybuf;
	vector<string> vectorString;

	cout<<"option:"<<selectedOption<<"  copybuf:"<<copybuf<<endl;
	cout<<"ref:"<<refStr<<endl;
	switch(selectedOption){
			case 1:
				input.callMovieInputFunc( copybuf);

				/*check if the movie parameters is valid */
				if(CheckIfMovieCodeValid(input.getMovieCode()) &&
				   input.isMovieLengthValid(input.getlength())&&
				   input.isMovieRatingValid(input.getRating()) &&
				   input.isYearOfPublicValid(input.getYearOfPublic()))
				{
					/*create and add the movie to the vector*/
					movie=createNewMovie();
					addNewMovie(movie);
					returnString=(output.printSuccess());
				}
				else
					returnString=(output.printFailure());
				break;
			case 2:
				input.callProInputFunc(copybuf);

				if(CheckIfProIDValid(input.getID()) &&
				   input.isProAgeValid(input.getAge()) &&
				   input.isProGenderValid(input.getGender()) &&
				   input.isProTypeValid(input.getTypeOfPro()))
				{
					pro=createNewProfessional();
					addNewProfessional(pro);
					returnString=(output.printSuccess());
				}

				else
					returnString=(output.printFailure());
				break;
			case 3:
				input.callToInputMovieCode(copybuf);
				input.callToInputID(copybuf);
				/*check if there exist movie with the same code
				*  and professional with the same  ID in the system */
				if((CheckIfMovieCodeValid(input.getMovieCode())==false)&&
				   (CheckIfProIDValid(input.getID())==false))
				{

						/*search the movie in the vector*/
						movie=searchMovie(input.getMovieCode());
						/*if the professional doesn't exist in the movie vector
						 * already */
						if((movie->searchProInMovie(input.getID()))==NULL)
						{

							/*search the professional in the vector*/
							pro=searchProfessional(input.getID());
							/*add the professional to the movie's private
							 professionals list */
							movie->addProToMovie(pro);
							/*add the movie to the professional's movies
							 * personal vector*/
							pro->addMovieToVector(movie);
							returnString=(output.printSuccess());
						}
						else
							returnString=(output.printFailure());
				}

				else{
					returnString=(output.printFailure());
				}
				break;

			case 4:
				input.callToInputMovieCode(copybuf);
				input.callToInputGenreString(copybuf);
			    /*check if the movie exist in the system */
				if((CheckIfMovieCodeValid(input.getMovieCode()))==false){
					/*search the movie in the vector*/
					movie=searchMovie(input.getMovieCode());
					/*check if the movie not belong to the genre already*/
					if(movie->searchGenre(input.getGenreString())==NULL){
						/* create and add the genre to the genre list */
						genre=addGenre(input.getGenreString());
						/* add the genre to the movie */
						movie->addGenreToMovie(genre);
						/*add the movie to the genre*/
						genre->addMovieToVector(movie);

						returnString=(output.printSuccess());
					}
					else{ // the movie already belongs to the genre
						returnString=(output.printFailure());
					}
				}
				else //the is no movie with this code
					returnString=(output.printFailure());

				break;

			case 5:
				input.callToInputMovieCode(copybuf);
				input.InputSortBy(copybuf);
				/*if exist in the system movie with that code and the value of
				 type of sort is valid */
				if((CheckIfMovieCodeValid(input.getMovieCode())==false)&&
				    input.isTypeOfSortValid())
				{
					/*search the movie in the vector*/
					movie=searchMovie(input.getMovieCode());
					//set the type of sorting
					movie->dec.setSort(input.getSortBy());
					//sort the movie professional list according the wanted type
					movie->sortProfessional();

					returnString=(output.printSuccess());
				}
				else
					returnString=(output.printFailure());

				break;
			case 6:
				input.callToInputMovieCode(copybuf);
				if((CheckIfMovieCodeValid(input.getMovieCode())==false)){
					/*search the movie in the vector*/
					movie=searchMovie(input.getMovieCode());
					returnString=(output.printMoviePro(movie));
				}
				else
					returnString=(output.printFailure());
				break;
			case 7:
				input.callToInputMovieCode(copybuf);
			/*check if there exist movie with the same code in the system */
				if((CheckIfMovieCodeValid(input.getMovieCode())==false))
				{
					/*search the movie in the vector*/
					movie=searchMovie(input.getMovieCode());
					/*print the movie details */
					returnString=(output.printMovie(movie));
				}
				else{//if the movie didn't found in the system
					returnString=(output.printFailure());
				}
				break;
			case 8:
				stri=input.InputUnitedMovies(copybuf);
				if(IsUnionMoviesValid(vectorString,stri)){
					movie=createUnitedMovie(vectorString);
					addUnitedMovie( movie);
					returnString=(output.printSuccess());
				}
				else
					returnString=(output.printFailure());

				break;
			case 9:
				input.callToInputID(copybuf);
				if(CheckIfProIDValid(input.getID())==false){
				/*search the professional in the vector*/
					pro=searchProfessional(input.getID());
					returnString=pro->printMyMovies();
				}
				break;
			case 10:
				input.callToInputMovieCode(copybuf);
				/*check if the movie exist in the system*/
				if((CheckIfMovieCodeValid(input.getMovieCode())==false)){
					/*search the movie in the vector*/
					movie=searchMovie(input.getMovieCode());
					/*delete movie from professional's movie list*/
					deleteMovieFromProList(input.getMovieCode());
					/*delete movie from genre's movie list*/
					deleteMovieFromGenreList(input.getMovieCode());
					/*delete movie from system's movie list*/
					deleteMovie(input.getMovieCode());
					returnString=(output.printSuccess());

				}
				else
					returnString=output.printFailure();
				break;
			case 11:
				input.callToInputID(copybuf);
				/*check if the professional exist in the system */
				deleteProFromMovieList(input.getID());
				if(CheckIfProIDValid(input.getID())==false){
					/*delete the professional from the movie proList*/
					deleteProFromMovieList(input.getID());
					/*delete the professional from the system*/
					deleteProfessional(input.getID());
					returnString=output.printSuccess();

				}
				else
					returnString=output.printFailure();
				break;
			case 12:
				input.callToInputMovieCode(copybuf);
				input.callToInputID(copybuf);
				/*check if there exist movie with the same code
				 *  and professional with the same  ID in the system */
				if((CheckIfMovieCodeValid(input.getMovieCode())==false)&&
				   (CheckIfProIDValid(input.getID())==false))
				{
					movie=searchMovie(input.getMovieCode());
					/*if the professional  exist in the movie vector */
					if((movie->searchProInMovie(input.getID()))!=NULL){
						movie->deleteProFromMovie(input.getID());
						returnString=output.printSuccess();
					}
					else
						returnString=output.printFailure();
				}
				else
					returnString=output.printFailure();
				break;
			case 13:
				returnString=printAllMovies();
				break;
			case 14:
				returnString=printAllProffession();
				break;
			case 15:
				input.callToInputGenreString(copybuf);
				/*if the genre exist in the system*/
				if(checkIfGenreIsvalid(input.getGenreString())){
					genre=searchGenre(input.getGenreString());
					returnString= genre->printMymovies();
				}
				else
					returnString=output.printFailure();
				break;

			default:
				returnString=output.printFailure();

   }
	cout<<"return string:"<<returnString<<endl;
	return returnString;
}
/****************************************************************
* The function addNewMovie() create dynamic allocation of Movie
* object,initialize it by the user input and add the movie into a
* vector of type Movie*
*****************************************************************/
Movie* SystemAdministrator::createNewMovie(){
	string code;
	string nameOfMovie;
	string desc;
	double length,rating;
	int yearOfPublic;
    /*get the movie parameters */
	code=input.getMovieCode();
	nameOfMovie=input.getMovieName();
	desc=input.getMovieSummery();
	length=input.getlength();
	rating=input.getRating();
	yearOfPublic=input.getYearOfPublic();

	movieList.reserve(1);//make room for 1 movie element
	/*Allocated a new movie dynamically */
   Movie* Movieptr=new Movie(code,nameOfMovie,length,yearOfPublic,rating,desc);
   Movieptr->dec.setSort(1); //initialize the movie to defult sort
   return Movieptr;//return the movie we creating

}

/****************************************************************
* The function addNewMovie(Movie *m) receive a pointer to movie
*  add the pointer into a  vector of type Movie*
*****************************************************************/
void SystemAdministrator::addNewMovie(Movie *movie){

		movieList.push_back(movie);
}
/*****************************************************************
* The function addProfessional() create dynamic allocation of
* specific Professional  object, initialize it by the user input
* and add the Professional into a vector of  type Professional *
******************************************************************/
Professional* SystemAdministrator::createNewProfessional(){
	int age,typeOfPro;
	string nameOfPro;
	string ID;
	string specificDes;
	string gender;
	Professional* pro;
	/*get the professional parameters */
	ID=input.getID();
	age=input.getAge();
	typeOfPro=input.getTypeOfPro();
	nameOfPro=input.getProName();
	specificDes=input.getSpecificDes();
	gender=input.getGender();

	professionalList.reserve(1);//make room for 1 professional element
	if(typeOfPro==DIRECTOR){
		/*allocated dynamiclay Director */
		pro=new Directors(ID,nameOfPro,specificDes,age,gender);
	}
	else if(typeOfPro==ACTRESS){
		/*allocated dynamiclay Actress */
		pro=new Actress(ID,nameOfPro,specificDes,age,gender);
	}
	else if(typeOfPro==SCREEN_WRITER){
		/*allocated dynamiclay ScreenWriter */
		pro=new ScreenWriters(ID,nameOfPro,specificDes,age,gender);
	}
	else if(typeOfPro==PRODUCER){
		/*allocated dynamiclay Producer */
		pro=new Producers(ID,nameOfPro,specificDes,age,gender);
	}
	return pro;//return the poinrter to the professional we created
}
/*****************************************************************
* The function addNewProfessional(Professional *pro) receive a
* pointer to professional and add the pointer into a vector of
* type Professional *
******************************************************************/
void SystemAdministrator::addNewProfessional(Professional *pro){
	professionalList.push_back(pro);
}
/******************************************************************
* The function addGenre(string genreString) receive a genre string ,
* create dynamicaly genre and add it to the genre vector
*******************************************************************/
Genre* SystemAdministrator::addGenre(string genreString){
	Genre *gen=new Genre(genreString);
	 GenreList.push_back(gen);
	return gen;
}
/******************************************************************
* The function addUnitedMovie(Movie* m) getting a movie which
* is result of two movies and add it to the vector of type  movie*
*******************************************************************/
void SystemAdministrator::addUnitedMovie(Movie* movie){

	/*set sort by to default (sort by Id) */
	movie->dec.setSort(1);
	movieList.push_back(movie);
	vector<Genre*> vectorGen=movie->getGenreVector();
	vector<Genre*>::iterator it;
	/*iterate over the union Genre vector */
	for(it=vectorGen.begin();it!=vectorGen.end();++it){
		/*add the movie to the genre*/
		(*it)->addMovieToVector(movie);
	}

	vector<Professional*> vectorPro=movie->getProVector();
	vector<Professional*>::iterator itPro;
	/*iterate over the union professional vector */
	for(itPro=vectorPro.begin();itPro!=vectorPro.end();++itPro){
		/*add the movie to the Professional*/
		(*itPro)->addMovieToVector(movie);
	}
}
/*************************************************************
* The function searchMovie(string movieCode) getting the code of
* the selected movie  and search the movie in the vector
* movieList ,if the movie found in the vector  the function
* return pointer to it' otherwise return null
**************************************************************/
Movie*  SystemAdministrator::searchMovie(string movieCode){
	Movie *movie;
	movie=s.search(movieList,movieCode);
	return movie;
}
Genre* SystemAdministrator::searchGenre(string genreString){
	Genre *genre;
	genre=s.search(GenreList,genreString);
	return genre;
}
/*************************************************************
* The function  searchProfessional(int ID) getting the ID of
* the selected professional and search the professional in the
* vector professionList ,if the professional found in the
* vector the function return pointer to it'otherwise return
* null
************************************************************/
Professional* SystemAdministrator::searchProfessional(string ID){
	Professional *pro;
	pro=s.search(professionalList,ID);
	return pro;
}

/**************************************************************
* The function printProfessional(int ID) printing a specific
* professional according the professional ID  from user.
***************************************************************/
void SystemAdministrator::printProfessional(string ID){
	vector<Professional*>::iterator it;
	/*if the professional vector not empty */
	if((professionalList).size()!=ZERO){
		for(it=(professionalList).begin();it!=(professionalList).end();++it){
			(*it)->printProfessional();
		}
	}
	else
		professionalList[ZERO]->printProfessional();

}
/******************************************************************
* The function deleteProfessional( int ID) delete a specific
* professional from the list and from the heap.
*******************************************************************/
void SystemAdministrator::deleteProfessional(string ID){
	vector<Professional*>::iterator it;
	int resultCmp;
	for(it=(professionalList).begin(); it !=(professionalList).end(); ++it) {
			resultCmp=ID.compare((*it)->getID());
			/*if we fount the professional we search for */
			if(resultCmp==ZERO){
				/*delete the Professional from the heap (from the memory)*/
				(*it)->deletePro(*it);
				/*delete the professional from the system */
				professionalList.erase(it);
				break;
			}
    }
}
/*******************************************************************
* The function deleteMovie( movieCode:int),delete a specific movie
* from the list and from the heap.
*******************************************************************/
void SystemAdministrator::deleteMovie(string movieCode){
	vector<Movie*>::iterator it;
	int resultCmp;
	string codeOfCurrentMovie;
	for(it=(movieList).begin(); it !=(movieList).end(); ++it) {
		codeOfCurrentMovie=((*it)->getCode());
		resultCmp=codeOfCurrentMovie.compare(movieCode);
		if(resultCmp==ZERO){
			/*delete the movie from the heap (from the memory)*/
			(*it)->deleteMovie(*it);
			/*delete the movie from the system */
			movieList.erase(it);
			break;
		}
	}
}
/***************************************************************
* The function CheckIfMovieCodeValid() check if the movie's code
* is valid ,if it is return true else return false
**************************************************************/
bool SystemAdministrator::CheckIfMovieCodeValid(string code){
	Movie *m;
	m=searchMovie(code);
	if(m!=NULL) //if already exist movie with the same code
        return false;
	return true;
}
/***************************************************************
* The function checkIfGenreIsvalid(string genreString) check if
* the movie's genre is valid ,if it is return true else return
* false
**************************************************************/
bool SystemAdministrator::checkIfGenreIsvalid(string genreString){
	Genre *gen;
	gen=searchGenre(genreString);
	if(gen!=NULL) //if the genre exist in the system
	   return true;
	return false; //if the genre doesn't exist in the system
}
/***************************************************************
* The function CheckIfProIDValid(int id) check if the professional
*  ID is valid ,if it is return true else return false
**************************************************************/
bool SystemAdministrator::CheckIfProIDValid(string id){
	Professional *pro;
	pro=searchProfessional(id);
	if(pro!=NULL) //if already exist professional with the same ID
	   return false;
    return true;
}
/*********************************************************************
* the function IsUnionMoviesValid(vector<string>& vectorString,string str)
* check for each movie we want to united if its code valid (exist in the
* system) if it is return true ,otherwise return false.
**********************************************************************/
bool SystemAdministrator::IsUnionMoviesValid( vector<string>& vectorString,
		                                      string str){
	istringstream iss(str);
	string token;
	vector<string>::iterator it;

	/*separate the movie's code one by one from str*/
	while (std::getline(iss, token, ','))
	{
		vectorString.push_back(token);
	}
	/*if user gave only ine movie code, its code already exist
	 *  in the system*/
	if(vectorString.size()<=1)
		return false;
	/*check for each movie code if there exist movie with this code*/
	for(it=vectorString.begin();it!=vectorString.end();++it){
		/*if the is no movie with this code */
		if(CheckIfMovieCodeValid(*it))
			return false;
	}

	/*if all the movie's code in the system */
	return true;
}
/*******************************************************************
* the function createUnitedMovie( vector<string>& vectorString)
* receive a vector of string which contains the movie code of all
* the movies we want to united, and create from them the united movie.
* the function return a pointer to the united movie
********************************************************************/
Movie* SystemAdministrator::createUnitedMovie(vector<string>& vectorString){
	vector<string>::iterator it;

	string str=vectorString.at(ZERO);
	Movie *movie=searchMovie(str);
	/*initialize  movie_A with the first movie,movie movie_A
	* will be the result of all the united movies*/

	Movie movie_A(movie); // copy all the first movie details
	for(it=vectorString.begin()+1 ;it !=(vectorString).end(); ++it){

		movie=searchMovie(*it);
		/*initialize  movie_B with the second movie*/
		Movie movie_B(movie);
		movie_A=(movie_A + (movie_B));//add the two movies
	}
	Movie *p=&movie_A;
	Movie *UnitedMovie=new Movie(p);
	return UnitedMovie;
}

/******************************************************************
* The function deleteProFromMovieList(string ID) delete a specific
* professional from the  movie professional list .
*******************************************************************/
void SystemAdministrator::deleteProFromMovieList(string ID){
	vector<Movie*>::iterator it;
		for(it=(movieList).begin(); it !=(movieList).end(); ++it){
			(*it)->deleteProFromMovie(ID);
		}
}
/******************************************************************
* The function deleteMovieFromProList(string code) receive the
* movie code which we want to delete , and remove the movie from the
* professional movie vector.
*******************************************************************/
void SystemAdministrator::deleteMovieFromProList(string code){
	vector<Professional*>::iterator it;
	for(it=(professionalList).begin(); it !=(professionalList).end(); ++it){
		(*it)->DeleteMovieFromVector(code);
	}
}
/******************************************************************
* The function deleteMovieFromGenreList(string code) receive the
* movie code which we want to delete , and remove the movie from the
* genre movie vector (in class Movie).
*******************************************************************/
void SystemAdministrator::deleteMovieFromGenreList(string code){
	vector<Genre*>::iterator it;
	for(it=(GenreList).begin(); it !=(GenreList).end(); ++it){
		(*it)->deleteMovie(code);
	}
}
/************************************************************
* distructor of the SystemAdministrator class
************************************************************/
SystemAdministrator::~SystemAdministrator(){}







