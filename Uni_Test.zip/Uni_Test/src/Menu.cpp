/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "Menu.h"
#define ONE 1
#define FIFTEEN 15
#define SPACE " "
/****************************************************************
* The function  selectOption() get from user a selected option
* in order to perform it .the function return the selected option
* to the system.
*****************************************************************/
int Menu::selectOption(string& buf){
	cout<<"menu buf is:"<<buf<<endl;
	int option;
	string delimiter =SPACE;
	int at=buf.find(delimiter);
	string op = buf.substr(0, at); // token is the option
	sscanf (op.c_str(), "%d",&option);//convert string to int
	buf=buf.substr(at+1);//the buf not contains the option anymore
	return option;

	/*
	int index=0;
	int option;

	while(buf[index]!=' '){
			index++;
	}
	char *arr = new char[index];
	for(int j=0;j<index;j++)
		arr[j]=buf[j];
    /*convert arr  char to int*/
	/*
	sscanf (arr, "%d",&option);

	buf=buf.substr(index+1);// the string not contains the option

	return option;*/
}
/****************************************************************
* The function isOptionValid(int selectOption) check if the
* option is valid, if it is  return true else ,return false
***************************************************************/
bool Menu::isOptionValid(int selectOption){
	if(selectOption>= ONE && selectOption<=FIFTEEN )
		return true;
	else
		return false;
}
/****************************************************************
* the function void setOption(int op) set the option member by
* the value from the user
***************************************************************/
void Menu::setOption(int op){
	option=op;
}
/***************************************************************
* The function int getOption() return the option
**************************************************************/
int Menu::getOption(){
	return option;
}
/***************************************************************
* Distructor of the Menu class
**************************************************************/
Menu::~Menu(){ }
