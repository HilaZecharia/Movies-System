/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include "SortByAge.h"

/****************************************************************
* the function operator()(Professional *pro1,Professional *pro2)
* receive two pointers to professionals and compare between them
* by age, the function return true if pro1 age is bigger the pro2
* age,and return false otherwise.
*****************************************************************/
bool SortByAge::operator()(Professional *pro1,Professional *pro2) {

	int age1,age2;
	age1=pro1->getAge();
	age2=pro2->getAge();
	/*if pro 2 is older then pro 1*/
	if(age1<age2)
		return false;
	/*if pro 1 is older then pro 2*/
	else
		return true;

}
/*******************************************************************
* virtual distructor of the SortByAge class
******************************************************************/
SortByAge::~SortByAge() { }


