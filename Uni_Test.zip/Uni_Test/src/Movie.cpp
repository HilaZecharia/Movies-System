/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
#include <string>
#include <iostream>
#include <vector>
#include  <algorithm>

#include "Movie.h"
using namespace std;


/*******************************************************************
* Constructor Movie initialize the movie object by the constructor's
* parameters .
********************************************************************/
Movie::Movie(string code, string nameOfMovie,double length,int yearOfPublic,
		     double rating,string summery){
	this->code=code;
	this->nameOfMovie= nameOfMovie;
	this->length=length;
	this->yearOfPublic=yearOfPublic;
	this->rating=rating;
	this->summery=summery;
	this->s=new SearchInVector();

}
/*******************************************************************
* constructor Movie(const Movie &M)  is an copy constructor,
* getting a reference to movie and  make another movie which
* is a copy of the reference movie.
*******************************************************************/
Movie::Movie(Movie *movie){
	this->code=((*movie).getCode());
	this->nameOfMovie= movie->getMovieName();
	this->length=movie->getLength();
	this->yearOfPublic=movie->getYearOfPublic();
	this->rating=movie->getRating();
	this->summery=movie->getSummery();
	this->MyProList=movie->getProVector();
	this->genreList=movie->getGenreVector();
	this->s=new SearchInVector();
}

/********************************************************************
* the function getProVector() return the professional vector of
* the movie
********************************************************************/
vector<Professional*>& Movie::getProVector (){
	return MyProList;
}
/*******************************************************************
* the function  getGenreVector() return the genre vector of the
* movie
******************************************************************/
vector<Genre*>& Movie::getGenreVector (){
	return genreList;
}
/******************************************************************
* the function returnGenreString() return the genre string
*****************************************************************/
string Movie::returnGenreString(){
	vector<Genre*>::iterator it;
	string generStrings="";
    /*create a string with all the movie's genres */

	for(it=( genreList).begin();it!=( genreList).end();++it)
	{
		if(it==( genreList).begin())
				generStrings=((*it)->getGenreString());
		else
			generStrings=generStrings+","+((*it)->getGenreString());
	}
	return generStrings;
}
/******************************************************************
* the function getSummery() return the movie summary
*****************************************************************/
string Movie::getSummery(){
	return summery;
}
/*****************************************************************
* the function getYearOfPublic() return the movie's year of public
*****************************************************************/
int Movie::getYearOfPublic(){
	return yearOfPublic;
}
/*****************************************************************
* the function getRating() return the movie rating
****************************************************************/
double Movie::getRating(){
	return rating;
}

/*******************************************************************
* The function operator+( Movie& other)  perform the + operator
* between to pointers to movies object.the fuction get pointer to
* other movie and add is to the movie which this function has called.
* the function return a new movie* as a result
********************************************************************/
Movie Movie:: operator+(Movie& other){

	/*we take the longest movie details*/
	if(length<other.getLength()){
		length=other.getLength();
		nameOfMovie=other.getMovieName();
		yearOfPublic=other.getYearOfPublic();
		rating=other.getRating();
		summery=other.getSummery();

	}
	/*add the other movie's code */
	code=code+"_"+other.getCode();
	/*union the genre lists*/
	s->unionVectors(other.getGenreVector(),genreList);
	/*union the professionals lists*/
	s->unionVectors(other.getProVector(),MyProList);
	Movie ret(this);
	return ret;
}
/*******************************************************************
* The function operator=( Movie movie)  perform the = operator as
* assign movie into another movie .
* ******************************************************************/
void  Movie:: operator=(Movie movie){

	this->code=movie.getCode();
	this->nameOfMovie= movie.getMovieName();
	this->length=movie.getLength();
	this->yearOfPublic=movie.getYearOfPublic();
	this->rating=movie.getRating();
	this->summery=movie.getSummery();
	this->MyProList=movie.getProVector();
	this->genreList=movie.getGenreVector();

}

/********************************************************************
* the function getLength() return the length of the movie
*******************************************************************/
int Movie::getLength(){
	return length;
}

/******************************************************************
* The function searchProInMovie(int ID) search professional in the
* movie professional list by Id and return pointer to it
******************************************************************/
Professional* Movie::searchProInMovie(string ID){
	Professional *pro;
	pro=s->search(MyProList,ID);
	return pro;

}
/******************************************************************
* The function deleteProFromMovie(int ID)  delete the professional
* from the movie's professional list acoording its ID.
*******************************************************************/
void Movie::deleteProFromMovie(string ID){
	vector<Professional*>::iterator it;
	int resultCmp;
	for(it=(MyProList).begin(); it !=(MyProList).end(); ++it) {
		resultCmp=ID.compare(((*it)->getID()));
		if(resultCmp==0){
			/*delete the professional from the movie Pro list*/
			MyProList.erase(it);
			break;
		}
	}
}
/*****************************************************************
* The function void addGenreToMovie(String s) get a string of the
* Genre and initialize the member Genre by it .
*****************************************************************/
void Movie:: addProToMovie( Professional *pro){
	/*add the professional to this movie vector*/
	MyProList.push_back(pro);

}
/*****************************************************************
* The function void addGenreToMovie(String s) get a string of the
* Genre and initialize the member Genre by it .
*****************************************************************/
void  Movie::addGenreToMovie(Genre *genre){
	genreList.reserve(1);//make room for 1 genre element
	genreList.push_back(genre);
}

/*********************************************************************
* The function void deleteMovie() delete the movie which this function
* has called to from the heap
**********************************************************************/
void Movie::deleteMovie(Movie* m ){
	delete m;
}

/*********************************************************************
* The function sortProfessional() get input from user in
* which way to sort the professional vector of the movie,and the
* function sorted by it.
*********************************************************************/
void Movie::sortProfessional(){
	std::sort (MyProList.begin(), MyProList.end(), dec);
}

/*******************************************************************
* The function getMovieName() return the movie name
******************************************************************/
string Movie::getCode(){
	return code;
}
/*********************************************************************
* The function void deleteMovie() delete the movie which this function
* has called to from the heap
**********************************************************************/
Genre* Movie::searchGenre(string genreString){
	Genre *genre;
	genre=s->search(genreList,genreString);
	return genre;
}

/*******************************************************************
* The function getMovieName() return the movie name
******************************************************************/
string Movie::getMovieName(){
	return nameOfMovie;
}
/*****************************************************************
* the function getValueToSearchBy() use to get
* the movie code string in the generic search function.
* the function return the movie code string
*****************************************************************/
string Movie::getValueToSearchBy(){
	return  getCode();
}
/*******************************************************************
* Distructor of the Movie class
******************************************************************/
Movie::~Movie(){ }

