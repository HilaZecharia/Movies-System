/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/


#include "gtest/gtest.h"
#include "Actress.h"
using namespace std;

class ActressTest : public ::testing::Test {
    protected:
		Actress *actor;
		Movie *movie1;

	virtual void SetUp(){
		cout << "Setting up GenreTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down GenreTest" << endl;
		delete actor;
		delete movie1;

	}
	public:
	ActressTest(){
		actor= new Actress("123456789","Leonardo Dicaprio","Dude",42,"male");
		movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
	}

};

/*test to check that the function,"printProfessional" printed
 * the actor details correctly */

TEST_F(ActressTest,isPrintProfessionalWork){
	string ActressPrint="Leonardo Dicaprio 42\n";
	int result;
	testing::internal::CaptureStdout();
	actor->printProfessional();
	string output = testing::internal::GetCapturedStdout();
	result=ActressPrint.compare(output);
	EXPECT_EQ(0,result);
}

/*test to check that the function,"printMyMovies" printed
 * the movie details correctly */

TEST_F(ActressTest,isPrintMyMoviesWork){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	int result;
	actor->addMovieToVector(movie1);
	testing::internal::CaptureStdout();
	actor->printMyMovies();
	string output = testing::internal::GetCapturedStdout();
	result=moviePrint.compare(output);
	EXPECT_EQ(0,result);
}

