/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Professional.h"
#define INITIALIZE_VALUE 0

using namespace std;

class ProfessionalTest : public ::testing::Test {

	protected:
		virtual void SetUp(){
			cout << "Setting up proTest" << endl;

		}
		virtual void TearDown(){

			cout << "Tearing down proTest" << endl;

		}
	public:
		ProfessionalTest(){}

};

/*test to check if the compare function return the correct
 * comparing result*/

TEST_F(ProfessionalTest, getTest) {
     Professional p("123456789","Leonardo Dicaprio","Dude",42,"male");
	 int age=p.getAge();
	 string id=p.getID();
	 int resultCmp;
	 resultCmp=id.compare("123456789");
	 EXPECT_EQ(42,age);
	 EXPECT_EQ(0, resultCmp);

}

