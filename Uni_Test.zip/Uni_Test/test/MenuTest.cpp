/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Menu.h"
using namespace std;

class MenuTest : public ::testing::Test {
	protected:
		Menu m;

	virtual void SetUp(){
		cout << "Setting up MenuTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down MenuTest" << endl;

	}
	public:
	MenuTest(){}

};

/*test to check that the function "isInputOptionValid"
 * return the correct boolean result for the input */

TEST_F(MenuTest,isOptionValid){
	bool b;
	int op;
	op=1;
	b=m.isOptionValid(op);
	ASSERT_TRUE(b);
}
/*test to check if the input Of 'selectOption' absorbed in the system*/

TEST_F(MenuTest,isOptionIscorrect){
	int op=1;
	m.setOption(op);
	int result=m.getOption();
	EXPECT_EQ(op,result);
}

