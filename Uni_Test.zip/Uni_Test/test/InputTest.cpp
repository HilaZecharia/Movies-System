/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/
/*
#include "gtest/gtest.h"
#include "Input.h"
using namespace std;

class InputTest : public ::testing::Test {
	protected:
	virtual void SetUp(){
		cout << "Setting up inputTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down inputTest" << endl;

	}
	public:
	InputTest(){}

};
*/


/************* Input Movie Test *************/

/*test to check if the input Of 'MovieName' absorbed in the system*/
/*
TEST_F(InputTest, IsMovieNameIsCorrect) {
	Input input;
	string inputString;
	string s="xyz";
	int result;
	input.setMovieName(s);
	inputString=input.getMovieName();
	cout<<"inputString:"<<inputString<<endl;
	result=inputString.compare(s);
	EXPECT_EQ(0, result);
}
*/
/*test to check if the input Of 'Moviecode' is valid*/
/*
TEST_F(InputTest, IsMovieCodeValid) {
	string inputCodeValid;
	string inputCodeNotValid;
	bool resultValid,resultNotValid;
	resultValid=input.CheckIfMovieCodeValid(inputCodeValid);
	resultNotValid=input.CheckIfMovieCodeValid(inputCodeNotValid);
	EXPECT_TRUE(resultValid);
	EXPECT_FALSE(resultNotValid);
}*/

/*test to check if the input Of 'movieLenght' absorbed in the system
 * and it validity */
/*
TEST_F(InputTest, isLenghtValid){
	double validLength,notValidLength;
	bool resultValid,resultNotValid;
	resultValid=input.isMovieLengthValid(validLength);
	resultNotValid=input.isMovieLengthValid(notValidLength);
	EXPECT_TRUE(resultValid);
	EXPECT_FALSE(resultNotValid);
}*/

/*  test to check if the function "CallToInputMovieCode" call
 *  the function "inputMovieCode" and insert the code into
 *  the code member of input object*/
/*
TEST_F(InputTest,IsCallToInputMovieCodeWork){
	Input input;
	string code1,code2;
	int result;
	input.callToInputMovieCode();
	code1=input.getMovieCode();
	result=code1.compare(code2);
	ASSERT_EQ(0,result);
}*/
/* test to check if all the input movie's parameters
 * absorbs correctly in the system
 */
/*
TEST_F(InputTest,IsCallingAllTheMovieInputFuncWorks){
	string code;
	string nameOfMovie;
	double length,rating;
	int yearOfPublic,CmpResult;
	string summary;
	//call the function that call all the input's Movie functions
	input.callMovieInputFunc();
	CmpResult=code.compare(input.getMovieCode());
	EXPECT_EQ(0, CmpResult);
	EXPECT_EQ(length, input.getlength());
	EXPECT_EQ(yearOfPublic, input.getYearOfPublic());
	EXPECT_EQ(rating, input.getRating());
	CmpResult=nameOfMovie.compare(input.getMovieName());
	EXPECT_EQ(0,CmpResult);
	CmpResult=summary.compare(input.getMovieSummery());
	EXPECT_EQ(0,CmpResult);

}



/************* Input Professional Test *************/

/*test to check if the input Of 'professionlName' absorbed in the system*/
/*
TEST_F(InputTest, IsProNameIsCorrect) {
	string inputString;
	string s;
	int result;
	inputString=input.getProName();
	result=inputString.compare(s);
	EXPECT_EQ(result, 0);
}
/*test to check if the input Of 'professionalName' is valid*/
/*
TEST_F(InputTest, IsProNameIsNotEmpty) {
	string space=" ";
	string enter="\n";
	string inputString;
	int result1,result2;
	inputString=input.getProName();
	result1=inputString.compare(space);
	result2=inputString.compare(enter);
	EXPECT_NE(result1, 0);
	EXPECT_NE(result2, 0);
}
/*test to check if the function CallAllTheProInputFuncWorks call
 * all the professional's input correctly */
/*
TEST_F(InputTest,IsCallingAllTheProInputFuncWorks){
	int ID;
	string nameOfPro;
	string specificDes;
	int age;
	int gender;
	int typeOfPro;
	int CmpResult;
	//call the function that call all the input's Movie functions
	input.callProInputFunc();
	EXPECT_EQ(ID, input.getID());
	EXPECT_EQ(age, input.getAge());
	EXPECT_EQ(gender, input.getGender());
	EXPECT_EQ(typeOfPro ,input.getTypeOfPro());
	CmpResult=nameOfPro.compare(input.getProName());
	EXPECT_EQ(CmpResult, 0);
	CmpResult=specificDes.compare(input.getSpecificDes());
	EXPECT_EQ(CmpResult, 0);
}*/


