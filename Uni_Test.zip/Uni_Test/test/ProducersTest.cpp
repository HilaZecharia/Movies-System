/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Producers.h"
using namespace std;
/*class that checks all the  member of type 'string' in Input object*/

class ProducersTest : public ::testing::Test {
    protected:
	Producers *producer;
	Movie *movie1;

	virtual void SetUp(){
		cout << "Setting up GenreTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down GenreTest" << endl;
		delete producer;
		delete movie1;

	}
	public:
	ProducersTest(){
		producer=new Producers("123456789","Leonardo Dicaprio","Dude",42,"male");
		movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
	}

};

/*test to check that the function,"printProfessional" printed
 *the actor details correctly */

TEST_F(ProducersTest,isPrintProfessionalWork){
	string producerPrint="Leonardo Dicaprio\n";
	int result;
	testing::internal::CaptureStdout();
	producer->printProfessional();
	string output = testing::internal::GetCapturedStdout();
	result=producerPrint.compare(output);
	EXPECT_EQ(0,result);
}

/*test to check that the function,"printMyMovies" printed the movie
 *details correctly */

TEST_F(ProducersTest,isPrintMyMoviesWork){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	int result;
	producer->addMovieToVector(movie1);
	testing::internal::CaptureStdout();
	producer->printMyMovies();
	string output = testing::internal::GetCapturedStdout();
	result=moviePrint.compare(output);
	EXPECT_EQ(0,result);
}
