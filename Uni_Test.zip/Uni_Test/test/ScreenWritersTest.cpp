/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "ScreenWriters.h"
using namespace std;

class ScreenWritersTest : public ::testing::Test {
    protected:
	ScreenWriters *sw;
	Movie *movie1;

	virtual void SetUp(){
		cout << "Setting up GenreTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down GenreTest" << endl;
		delete sw;
		delete movie1;

	}
	public:
	ScreenWritersTest(){
		sw=new ScreenWriters("112233445","Zachary Levi","Chuck",36,"male");
		movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
	}

};

/*test to check that the function,"printProfessional" printed the actor
 *details correctly */

TEST_F(ScreenWritersTest,isPrintProfessionalWork){
	string directorPrint="Zachary Levi Chuck\n";
	int result;
	testing::internal::CaptureStdout();
	sw->printProfessional();
	string output = testing::internal::GetCapturedStdout();
	result=directorPrint.compare(output);
	EXPECT_EQ(0,result);
}
/*test to check that the function,"printMyMovies" printed the movie
 *details correctly */

TEST_F(ScreenWritersTest,isPrintMyMoviesWork){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	int result;
	sw->addMovieToVector(movie1);
	testing::internal::CaptureStdout();
	sw->printMyMovies();
	string output = testing::internal::GetCapturedStdout();
	result=moviePrint.compare(output);
	EXPECT_EQ(0,result);
}
