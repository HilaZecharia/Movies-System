/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Movie.h"
#include "SystemAdministrator.h"
#include "SearchInVector.h"
#include "Output.h"
using namespace std;

class MovieTest : public ::testing::Test {
public:
		Movie *movie1;
		Movie *movie2;
		Professional *pro;
		SystemAdministrator admin;

		virtual void SetUp(){
			cout << "Setting up MovieTest" << endl;

		}
		virtual void TearDown(){
			cout << "Tearing down MovieTest" << endl;
			delete movie1;
			delete movie2;
			delete pro;

		}

		MovieTest(){
			movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
			movie2=new Movie("xmen","X-Men",132,2014,8.1,"The X-Men send");
			pro=new Professional("123456789","Leonardo Dicaprio","Dude",42,"male");
		}

};


 /*test to check if the professional exist in the movie after added into
 * to the movie
 */

TEST_F(MovieTest,IsProfessionalAddToMovieTest){
	int cmp;
	SearchInVector s;
	//Professional *pro=new Professional("123456789","Leonardo Dicaprio","Dude",42,"male");
	movie1->addProToMovie(pro);
	Professional *proResult=s.search(movie1->getProVector(),"123456789");
	cmp=proResult->getID().compare("123456789");
	EXPECT_EQ(0,cmp);
}
/*test to check if the genre exist in the movie after added into
 * to the movie */

TEST_F(MovieTest,IsGenreAddToMovieTest){
    int cmp;
    SearchInVector s;
	string genString;
	Genre *gen=new Genre("SciFi");
	movie1->addGenreToMovie(gen);
	Genre *g=s.search(movie1->getGenreVector(),"SciFi");
	cmp=(g->getGenreString()).compare("SciFi");
	EXPECT_EQ(0,cmp);
}

/*test to check if movie details printed correct */


TEST_F(MovieTest,PrintMovieTest){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	Output out;
	testing::internal::CaptureStdout();
	out.printMovie(movie1);
	string output = testing::internal::GetCapturedStdout();
	 int result=moviePrint.compare(output);
	 EXPECT_EQ(0,result);

}






