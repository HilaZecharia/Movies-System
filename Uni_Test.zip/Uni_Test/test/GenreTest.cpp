/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Genre.h"
using namespace std;
/*class that checks all the  member of type 'string' in Input object*/

class GenreTest : public ::testing::Test {
protected:

	virtual void SetUp(){
		cout << "Setting up GenreTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down GenreTest" << endl;

	}
	public:
	GenreTest(){}

};

/*test to check that the function,"getGenreString"
 * work correctly */

TEST_F(GenreTest,isGetStringWorks){
	string s="SciFi";
	string get;
	int result;
	Genre *gen=new Genre("SciFi");
	get=gen->getGenreString();
	result=s.compare(get);
	EXPECT_EQ(0,result);
}

