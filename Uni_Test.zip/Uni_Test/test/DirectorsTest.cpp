/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "Directors.h"
using namespace std;

class DirectorsTest : public ::testing::Test {
    protected:
	Directors *dir;
	Movie *movie1;

	virtual void SetUp(){
		cout << "Setting up GenreTest" << endl;
	}
	virtual void TearDown(){
		cout << "Tearing down GenreTest" << endl;
		delete dir;
		delete movie1;

	}
	public:
	DirectorsTest(){
		dir=new Directors("112233445","Zachary Levi","Chuck",36,"male");
		movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
	}

};

/*test to check that the function,"printProfessional" printed the
 * actor details correctly */

TEST_F(DirectorsTest,isPrintProfessionalWork){
	string directorPrint="Zachary Levi\n";
	int result;
	testing::internal::CaptureStdout();
	dir->printProfessional();
	string output = testing::internal::GetCapturedStdout();
	result=directorPrint.compare(output);
	EXPECT_EQ(0,result);
}
/*test to check that the function,"printMyMovies" printed the movie
 *details correctly */

TEST_F(DirectorsTest,isPrintMyMoviesWork){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	int result;
	dir->addMovieToVector(movie1);
	testing::internal::CaptureStdout();
	dir->printMyMovies();
	string output = testing::internal::GetCapturedStdout();
	result=moviePrint.compare(output);
	EXPECT_EQ(0,result);
}

