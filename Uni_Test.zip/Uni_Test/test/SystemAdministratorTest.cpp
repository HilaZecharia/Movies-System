/***********************
 * Hila Zecharia
 * 204008007
 * 8921004
 ***********************/

#include "gtest/gtest.h"
#include "SystemAdministrator.h"
#include "Input.h"
#include "Movie.h"


using namespace std;

class SystemAdministratorTest : public ::testing::Test {

	public :
	SystemAdministrator admin;
	Movie *movie1;
	Professional *pro;
	Input input;
	  void SetUp(){
		cout << "Setting up " << endl;
	}
	  void TearDown(){
		cout << "Tearing down inputTest" << endl;

	}

	SystemAdministratorTest(){
		movie1=new Movie("xyz","Inception",148,2010,8.8,"This is the description");
		pro=new Actress("123456789","Leonardo Dicaprio","Dude",42,"male");
	}

};

              /*              TESTES              */

/*test to check if specific movie add to the 'movieList' vector */


TEST_F(SystemAdministratorTest,addNewMovie){
	int result;
	string code="xyz";
    string s;
	admin.addNewMovie(movie1);
	//pointer to the movie which added to the 'movieList'
	Movie *movieInList;
	movieInList=admin.searchMovie(code);
    s=movieInList->getCode();
	result=code.compare(s);
	ASSERT_EQ(0,result);
	delete movie1;
	delete pro;
}


/*test to check if specific professional add to
 *the 'professionList' vector */

TEST_F(SystemAdministratorTest,addNewProfessional){
	int result;
	string ID="123456789";
	string s;
	admin.addNewProfessional(pro);
	//pointer to the movie which added to the 'movieList'
	Professional *proInList;
	proInList=admin.searchProfessional(ID);
	s=proInList->getID();
	result=ID.compare(s);
	ASSERT_EQ(0,result);
	delete movie1;
	delete pro;
}

/*test to check  if the function "printAllMovies" print the movie
 * details correctly.
 */

TEST_F(SystemAdministratorTest,IsPrintAllMoviesWork){
	string moviePrint="xyz Inception 148 2010 8.8  This is the description\n";
	int result;
	admin.addNewMovie(movie1);
	testing::internal::CaptureStdout();
	admin.printAllMovies();
	string output = testing::internal::GetCapturedStdout();
	result=moviePrint.compare(output);
	EXPECT_EQ(0,result);
	delete movie1;
	delete pro;
}
/*test to check  if the function "printAllProffession"
 * print the professional details correctly.
 */

TEST_F(SystemAdministratorTest,IsPrintAllProWork){
	string ProPrint="Leonardo Dicaprio 42\n";
	int result;
	admin.addNewProfessional(pro);
	testing::internal::CaptureStdout();
	admin.printAllProffession();
	string output = testing::internal::GetCapturedStdout();
	result=ProPrint.compare(output);
	EXPECT_EQ(0,result);
	delete movie1;
	delete pro;
}

/*test to check if the searching movie in the vector by movie code
 * return a pointer to the movie correctly*/

TEST_F(SystemAdministratorTest,IsSearchMovieWork){
	admin.addNewMovie(movie1);
	string codeOfMovieSearch="xyz";
	Movie *m;
	int result;
	m=admin.searchMovie(codeOfMovieSearch);
	result=codeOfMovieSearch.compare(m->getCode());
	ASSERT_EQ(0,result);
	delete movie1;
	delete pro;
}
/*test to check if the searching Professional in the vector
 * by Professional ID return a pointer to the professional correctly*/

TEST_F(SystemAdministratorTest,IsSearchProWork){
	admin.addNewProfessional(pro);
	string ID="123456789";
	Professional *proResult;
	int result;
	proResult=admin.searchProfessional(ID);
	result=ID.compare(proResult->getID());
	ASSERT_EQ(0,result);
	delete movie1;
	delete pro;
}
/*test to check if the Professional  removed from the vector
 * after the function "deleteProfessional" has called */

TEST_F(SystemAdministratorTest,IsDeleteProWork){
	admin.addNewProfessional(pro);
	string ID="123456789";
	Professional *pro;

	int isDelete=0;
	admin.deleteProfessional(ID);
	pro=admin.searchProfessional(ID);
	if(pro==NULL){
		cout<<"yes its null"<<endl;
		isDelete=1;
	}
	else
		cout<<"not NULL"<<endl;
	cout<<"blabla"<<endl;

	 EXPECT_EQ(1,isDelete);
}
/*test to check if the movie removed from the vector
 * after the function "deleteMovie" has called */

TEST_F(SystemAdministratorTest,IsDeleteMovieWork){
	admin.addNewMovie(movie1);
	string code="xyz";
	Movie *m;
	bool b=false;
	admin.deleteMovie(code);
	m=admin.searchMovie(code);
	if(m==NULL)
		b=true;
	ASSERT_TRUE(b);
}







